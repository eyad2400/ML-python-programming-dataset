#!/bin/bash
# deploy/deploy.sh
# Linux Auto-Deploy (Ubuntu/Debian)

echo "Auto-Deploying Exam System..."

APP_PATH="/var/www/html/exam-website"
DB_NAME="exam_system"
DB_USER="root"
DB_PASS=""
BACKUP_DIR="/backups"

# Stop Apache
sudo systemctl stop apache2

# Backup DB
sudo mysqldump -u$DB_USER -p$DB_PASS $DB_NAME > /tmp/db_backup.sql

# Clean old
sudo rm -rf $APP_PATH/*

# Copy new (from Git or ZIP)
sudo git pull origin main
# OR: unzip new-version.zip -d $APP_PATH

# Import schema
sudo mysql -u$DB_USER -p$DB_PASS $DB_NAME < /tmp/db_backup.sql

# Permissions
sudo chown -R www-data:www-data $APP_PATH
sudo chmod -R 755 $APP_PATH

# Start Apache
sudo systemctl start apache2

echo "Deploy completed!"