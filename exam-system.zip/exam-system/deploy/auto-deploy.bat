@echo off
REM deploy/auto-deploy.bat
REM Auto-Deploy Script for Exam System
REM Windows 10 + XAMPP | Romania (RO) | EET | Nov 10, 2025

@echo Auto-Deploying Exam System...

REM === CONFIG ===
SET APP_PATH=C:\xampp\htdocs\exam-website
SET DB_NAME=exam_system
SET DB_USER=root
SET DB_PASS=
SET DB_HOST=localhost
SET LOG_FILE=%APP_PATH%\deploy.log

REM === LOG ===
echo [%date% %time%] Deploy started >> %LOG_FILE%

REM === STOP XAMPP ===
echo Stopping XAMPP...
C:\xampp\xampp-control.exe /S /stop
timeout /t 5 /nobreak >nul

REM === BACKUP DB (PRE-DEPLOY) ===
echo Backup database...
"C:\xampp\mysql\bin\mysqldump" -u%DB_USER% -p%DB_PASS% %DB_NAME% > "%APP_PATH%\backup-%date:~-4,4%%date:~-10,2%%date:~-7,2%-%time:~0,2%%time:~3,2%.sql"
echo DB backed up >> %LOG_FILE%

REM === DELETE OLD FILES ===
echo Cleaning old files...
rmdir /S /Q "%APP_PATH%\*" >nul 2>&1
echo Old files cleaned >> %LOG_FILE%

REM === COPY NEW FILES ===
echo Copying new files...
REM Replace with your source path, e.g.:
REM xcopy /E /I "D:\new-version\*" "%APP_PATH%"
echo New files copied >> %LOG_FILE%

REM === IMPORT SCHEMA ===
echo Importing schema...
"C:\xampp\mysql\bin\mysql" -u%DB_USER% -p%DB_PASS% %DB_NAME% < "%APP_PATH%\data\db.sql"
echo Schema imported >> %LOG_FILE%

REM === SEED DATA ===
echo Seeding test data...
"C:\xampp\mysql\bin\mysql" -u%DB_USER% -p%DB_PASS% %DB_NAME% < "%APP_PATH%\data\seed.sql"
echo Data seeded >> %LOG_FILE%

REM === SET PERMISSIONS ===
echo Setting permissions...
icacls "%APP_PATH%" /grant "IIS_IUSRS":(OI)(CI)F /T >nul 2>&1
echo Permissions set >> %LOG_FILE%

REM === START XAMPP ===
echo Starting XAMPP...
C:\xampp\xampp-control.exe /S /start
timeout /t 10 /nobreak >nul

REM === TEST DEPLOY ===
echo Testing deployment...
curl -f http://localhost/exam-website/index.html >nul 2>&1
if %errorlevel% == 0 (
    echo Deployment successful >> %LOG_FILE%
) else (
    echo Deployment failed >> %LOG_FILE%
)

echo [%date% %time%] Deploy ended >> %LOG_FILE%
echo Deployment complete!
pause