@echo off
REM deploy/backup-to-usb.bat
REM 30-Day Auto Backup to USB Drive
REM Non-overwriting, Super Admin only
REM Windows 10 + XAMPP | Romania (RO) | EET | Nov 10, 2025

@echo Backup to USB Starting...

REM === CONFIG ===
SET APP_PATH=C:\xampp\htdocs\exam-website
SET DB_NAME=exam_system
SET DB_USER=root
SET DB_PASS=
SET BACKUP_DIR=D:\ExamBackups
SET LOG_FILE=%BACKUP_DIR%\backup.log

REM === CHECK USB ===
if not exist %BACKUP_DIR% (
    echo USB drive not found at D:\ExamBackups
    pause
    exit /b 1
)

REM === CHECK SUPER ADMIN ===
REM Run as admin or check token (simplified)
echo Assuming super admin access...

REM === DATE STAMP ===
SET DATE_STAMP=%DATE:~-4,4%%DATE:~-10,2%%DATE:~-7,2%_%TIME:~0,2%%TIME:~3,2%
if "%TIME:~0,1%" == " " SET DATE_STAMP=%DATE:~-4,4%%DATE:~-10,2%%DATE:~-7,2%_0%TIME:~1,1%%TIME:~3,2%

REM === DB BACKUP ===
echo [%DATE_STAMP%] DB backup starting...
"C:\xampp\mysql\bin\mysqldump" -u%DB_USER% -p%DB_PASS% %DB_NAME% > "%BACKUP_DIR%\db_%DATE_STAMP%.sql"

if %ERRORLEVEL% == 0 (
    echo DB backup success >> %LOG_FILE%
) else (
    echo DB backup failed >> %LOG_FILE%
    pause
    exit /b 1
)

REM === APP FILES BACKUP ===
echo [%DATE_STAMP%] App files backup starting...
xcopy "%APP_PATH%\*" "%BACKUP_DIR%\app_%DATE_STAMP%" /E /I /Y >nul

if %ERRORLEVEL% == 0 (
    echo Files backup success >> %LOG_FILE%
) else (
    echo Files backup failed >> %LOG_FILE%
)

REM === NON-OVERRIDING CHECK ===
REM Check if backup exists, don't override
if exist "%BACKUP_DIR%\backup_%DATE_STAMP%.zip" (
    echo Backup already exists - skipping >> %LOG_FILE%
    goto end
)

REM === ZIP BACKUP ===
echo [%DATE_STAMP%] Creating ZIP...
powershell -Command "Compress-Archive -Path '%BACKUP_DIR%\db_%DATE_STAMP%.sql','%BACKUP_DIR%\app_%DATE_STAMP\*' -DestinationPath '%BACKUP_DIR%\backup_%DATE_STAMP%.zip' -Force"

if %ERRORLEVEL% == 0 (
    echo ZIP success >> %LOG_FILE%
    echo Backup complete to %BACKUP_DIR%\backup_%DATE_STAMP%.zip
) else (
    echo ZIP failed >> %LOG_FILE%
)

REM === CLEAN TEMP ===
rmdir /S /Q "%BACKUP_DIR%\app_%DATE_STAMP%" >nul 2>&1
del "%BACKUP_DIR%\db_%DATE_STAMP%.sql" >nul 2>&1

:end
echo [%DATE_STAMP%] Backup ended >> %LOG_FILE%
pause