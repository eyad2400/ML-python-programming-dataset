CREATE DATABASE exam_system CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE exam_system;

-- Users (Staff)
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin', 'proctor') NOT NULL,
  name_ar VARCHAR(100) NOT NULL,
  is_super_admin TINYINT(1) DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Exam Takers (Candidates & Trainees)
CREATE TABLE exam_takers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  national_id VARCHAR(14) UNIQUE NOT NULL,
  name_ar VARCHAR(100) NOT NULL,
  user_type ENUM('candidate', 'trainee') NOT NULL,
  added_by INT NOT NULL,
  added_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (added_by) REFERENCES users(id),
  INDEX(national_id)
);

-- Subjects
CREATE TABLE subjects (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  code VARCHAR(20) UNIQUE NOT NULL,
  duration_minutes INT DEFAULT 60,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Training Courses
CREATE TABLE training_courses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  course_number INT NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  created_by INT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (created_by) REFERENCES users(id),
  UNIQUE(name, course_number),
  INDEX(name),
  INDEX(start_date)
);

-- Course Subjects
CREATE TABLE course_subjects (
  id INT AUTO_INCREMENT PRIMARY KEY,
  course_id INT NOT NULL,
  subject_id INT NOT NULL,
  FOREIGN KEY (course_id) REFERENCES training_courses(id) ON DELETE CASCADE,
  FOREIGN KEY (subject_id) REFERENCES subjects(id),
  UNIQUE(course_id, subject_id)
);

-- Course Trainee Assignments
CREATE TABLE course_trainee_assignments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  course_id INT NOT NULL,
  national_id VARCHAR(14) NOT NULL,
  assigned_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (course_id) REFERENCES training_courses(id) ON DELETE CASCADE,
  FOREIGN KEY (national_id) REFERENCES exam_takers(national_id),
  UNIQUE(course_id, national_id)
);

-- Weekly Schedule Template
CREATE TABLE course_weekly_schedule (
  id INT AUTO_INCREMENT PRIMARY KEY,
  course_id INT NOT NULL,
  day_of_week TINYINT NOT NULL CHECK (day_of_week IN (0,1,2,3,4,6)), -- Sat=6, Sun=0, ..., Thu=4
  subject_id INT NOT NULL,
  trainer_id INT NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  created_by INT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (course_id) REFERENCES training_courses(id) ON DELETE CASCADE,
  FOREIGN KEY (subject_id) REFERENCES subjects(id),
  FOREIGN KEY (trainer_id) REFERENCES users(id),
  FOREIGN KEY (created_by) REFERENCES users(id),
  UNIQUE(course_id, day_of_week, start_time)
);

-- Daily Schedule (Generated)
CREATE TABLE course_daily_schedule (
  id INT AUTO_INCREMENT PRIMARY KEY,
  course_id INT NOT NULL,
  schedule_date DATE NOT NULL,
  subject_id INT NOT NULL,
  trainer_id INT NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  created_by INT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (course_id) REFERENCES training_courses(id) ON DELETE CASCADE,
  FOREIGN KEY (subject_id) REFERENCES subjects(id),
  FOREIGN KEY (trainer_id) REFERENCES users(id),
  FOREIGN KEY (created_by) REFERENCES users(id),
  UNIQUE(course_id, schedule_date, start_time)
);

-- Attendance
CREATE TABLE course_attendance (
  id INT AUTO_INCREMENT PRIMARY KEY,
  course_id INT NOT NULL,
  national_id VARCHAR(14) NOT NULL,
  attendance_date DATE NOT NULL,
  is_present TINYINT(1) DEFAULT 0,
  marked_by INT NOT NULL,
  marked_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (course_id) REFERENCES training_courses(id) ON DELETE CASCADE,
  FOREIGN KEY (national_id) REFERENCES exam_takers(national_id),
  FOREIGN KEY (marked_by) REFERENCES users(id),
  UNIQUE(course_id, national_id, attendance_date),
  INDEX(attendance_date)
);

-- Exam Attempts
CREATE TABLE exam_attempts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  national_id VARCHAR(14) NOT NULL,
  course_id INT NOT NULL,
  subject_id INT NOT NULL,
  score DECIMAL(5,2),
  attempt_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (national_id) REFERENCES exam_takers(national_id),
  FOREIGN KEY (course_id) REFERENCES training_courses(id),
  FOREIGN KEY (subject_id) REFERENCES subjects(id)
);

-- Archived Courses
CREATE TABLE archived_courses (
  id INT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  course_number INT NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  archived_by INT NOT NULL,
  archived_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (archived_by) REFERENCES users(id)
);

-- Trainee Course History
CREATE TABLE trainee_course_history (
  id INT AUTO_INCREMENT PRIMARY KEY,
  national_id VARCHAR(14) NOT NULL,
  course_id INT NOT NULL,
  course_name VARCHAR(100) NOT NULL,
  course_number INT NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  final_grade DECIMAL(5,2) NULL,
  attendance_percentage DECIMAL(5,2) NULL,
  archived_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (national_id) REFERENCES exam_takers(national_id),
  INDEX(national_id)
);

-- Activity Log
CREATE TABLE user_activity (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  national_id VARCHAR(14) NULL,
  action VARCHAR(100) NOT NULL,
  details TEXT,
  ip_address VARCHAR(45),
  timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE exam_sessions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  national_id VARCHAR(14) NOT NULL,
  token VARCHAR(64) NOT NULL,
  user_type ENUM('candidate', 'trainee') NOT NULL,
  expires_at DATETIME NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(token),
  INDEX(national_id),
  INDEX(expires_at)
);

-- Seed Admin
INSERT INTO users (username, password_hash, role, name_ar, is_super_admin) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'المدير الرئيسي', 1);
-- Password: password