-- data/db.sql
CREATE DATABASE IF NOT EXISTS exam_system CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE exam_system;
SET time_zone = '+02:00';

-- Users
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  name_ar VARCHAR(100) NOT NULL,
  role ENUM('admin', 'proctor') DEFAULT 'proctor',
  is_super_admin TINYINT(1) DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Subjects
CREATE TABLE subjects (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  code VARCHAR(10) UNIQUE NOT NULL,
  duration_minutes INT DEFAULT 60
);

-- Trainers
CREATE TABLE trainers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  national_id VARCHAR(14) UNIQUE NOT NULL,
  name_ar VARCHAR(100) NOT NULL,
  pin CHAR(4) NOT NULL
);

-- Training Courses
CREATE TABLE training_courses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  course_number INT NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  created_by INT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(name, course_number),
  FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Course Subjects
CREATE TABLE course_subjects (
  course_id INT NOT NULL,
  subject_id INT NOT NULL,
  PRIMARY KEY (course_id, subject_id),
  FOREIGN KEY (course_id) REFERENCES training_courses(id) ON DELETE CASCADE,
  FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE
);

-- Exam Takers
CREATE TABLE exam_takers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  national_id VARCHAR(14) UNIQUE NOT NULL,
  name_ar VARCHAR(100) NOT NULL,
  user_type ENUM('trainee', 'candidate') DEFAULT 'trainee',
  added_by INT NOT NULL,
  FOREIGN KEY (added_by) REFERENCES users(id)
);

-- Course Trainee Assignment
CREATE TABLE course_trainee_assignments (
  course_id INT NOT NULL,
  national_id VARCHAR(14) NOT NULL,
  PRIMARY KEY (course_id, national_id),
  FOREIGN KEY (course_id) REFERENCES training_courses(id) ON DELETE CASCADE,
  FOREIGN KEY (national_id) REFERENCES exam_takers(national_id) ON DELETE CASCADE
);

-- Exams
CREATE TABLE exams (
  id INT AUTO_INCREMENT PRIMARY KEY,
  subject_id INT NOT NULL,
  duration_minutes INT DEFAULT 60,
  passing_score INT DEFAULT 70,
  FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE
);

-- Exam Questions
CREATE TABLE exam_questions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  exam_id INT NOT NULL,
  question_text TEXT NOT NULL,
  option_a TEXT NOT NULL,
  option_b TEXT NOT NULL,
  option_c TEXT NOT NULL,
  option_d TEXT NOT NULL,
  correct_option TINYINT NOT NULL CHECK (correct_option IN (0,1,2,3)),
  FOREIGN KEY (exam_id) REFERENCES exams(id) ON DELETE CASCADE
);

-- Exam Attempts
CREATE TABLE exam_attempts (
  exam_id INT NOT NULL,
  national_id VARCHAR(14) NOT NULL,
  course_id INT NOT NULL,
  attempt_date DATE NOT NULL,
  start_time DATETIME,
  end_time DATETIME,
  score DECIMAL(5,2),
  total_questions INT,
  correct_answers INT,
  PRIMARY KEY (exam_id, national_id, attempt_date),
  FOREIGN KEY (exam_id) REFERENCES exams(id),
  FOREIGN KEY (national_id) REFERENCES exam_takers(national_id),
  FOREIGN KEY (course_id) REFERENCES training_courses(id)
);

-- Exam Sessions
CREATE TABLE exam_sessions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  national_id VARCHAR(14) NOT NULL,
  token VARCHAR(64) UNIQUE NOT NULL,
  user_type ENUM('candidate', 'trainee') NOT NULL,
  expires_at DATETIME NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (national_id) REFERENCES exam_takers(national_id)
);

-- Backup Log
CREATE TABLE backup_log (
  id INT AUTO_INCREMENT PRIMARY KEY,
  backup_file VARCHAR(255) NOT NULL,
  created_by INT NOT NULL,
  timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Activity Log
CREATE TABLE user_activity (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  national_id VARCHAR(14) NULL,
  action VARCHAR(100) NOT NULL,
  details TEXT,
  ip_address VARCHAR(45),
  timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Seed Admin
INSERT INTO users (username, password_hash, name_ar, role, is_super_admin) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'المدير الرئيسي', 'admin', 1);
-- Password: admin123