-- data/views.sql
USE exam_system;

-- Attendance Summary
CREATE OR REPLACE VIEW v_attendance_summary AS
SELECT 
  ca.course_id, c.name, c.course_number,
  ca.national_id, et.name_ar,
  COUNT(ca.attendance_date) as total_days,
  SUM(ca.is_present) as present_days,
  ROUND(SUM(ca.is_present)/COUNT(ca.attendance_date)*100, 2) as attendance_pct
FROM course_attendance ca
JOIN exam_takers et ON ca.national_id = et.national_id
JOIN training_courses c ON ca.course_id = c.id
GROUP BY ca.course_id, ca.national_id;

-- Active Courses
CREATE OR REPLACE VIEW v_active_courses AS
SELECT * FROM training_courses 
WHERE end_date >= CURDATE();