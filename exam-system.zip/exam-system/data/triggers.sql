-- data/triggers.sql
USE exam_system;

-- Auto-mark attendance when trainee starts exam
DELIMITER $$
CREATE TRIGGER after_exam_attempt_insert
AFTER INSERT ON exam_attempts
FOR EACH ROW
BEGIN
  INSERT IGNORE INTO course_attendance 
  (course_id, national_id, attendance_date, is_present, marked_by, marked_at)
  VALUES 
  (NEW.course_id, NEW.national_id, NEW.attempt_date, 1, 
   (SELECT created_by FROM training_courses WHERE id = NEW.course_id LIMIT 1), 
   NOW());
END$$
DELIMITER ;

-- Clean expired exam tokens
DELIMITER $$
CREATE EVENT cleanup_expired_tokens
  ON SCHEDULE EVERY 1 HOUR
  DO
    DELETE FROM exam_sessions WHERE expires_at < NOW();
$$
DELIMITER ;