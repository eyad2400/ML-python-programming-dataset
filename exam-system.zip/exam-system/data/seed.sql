-- data/seed.sql
USE exam_system;

-- Super Admin
INSERT INTO users (username, password_hash, name_ar, role, is_super_admin) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'المدير الرئيسي', 'admin', 1),
('proctor1', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'أحمد محمد', 'proctor', 0);

-- Subjects
INSERT INTO subjects (name, code, duration_minutes) VALUES
('الأدلة الرقمية', 'DF101', 120),
('تحليل البرمجيات الخبيثة', 'MAL201', 180),
('أمن الشبكات', 'NET301', 150);

-- Sample Course
INSERT INTO training_courses (name, course_number, start_date, end_date, created_by) VALUES
('دورة الأمن السيبراني', 1, '2025-11-15', '2025-12-20', 1);

-- Assign Subjects
INSERT INTO course_subjects (course_id, subject_id) VALUES
(1, 1), (1, 2), (1, 3);

-- Sample Trainees
INSERT INTO exam_takers (national_id, name_ar, user_type, added_by) VALUES
('29901010123456', 'محمد علي', 'trainee', 1),
('29902020234567', 'فاطمة أحمد', 'trainee', 1);

-- Assign to Course
INSERT INTO course_trainee_assignments (course_id, national_id) VALUES
(1, '29901010123456'), (1, '29902020234567');