// trainer/assets/trainer.js
// Shared utilities