<?php
// reports/export/pdf.php
require_once __DIR__ . '/../../vendor/tcpdf/tcpdf.php';

ob_clean();

// Create PDF
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
$pdf->SetCreator('Exam System');
$pdf->SetAuthor('RO Training Center');
$pdf->SetTitle($title);
$pdf->SetMargins(15, 20, 15);
$pdf->SetAutoPageBreak(TRUE, 15);
$pdf->setHeaderFont(Array('dejavusans', '', 12));
$pdf->setFooterFont(Array('dejavusans', '', 10));
$pdf->SetHeaderData('', 0, $title, "تاريخ الإصدار: " . date('Y-m-d H:i'));

$pdf->AddPage();
$pdf->SetFont('dejavusans', '', 12);

// Custom content per report
if (isset($report)) {
    $html = "<h2>تقرير الحضور</h2>
    <p><strong>الدورة:</strong> {$course['name']} #{$course['course_number']}</p>
    <p><strong>الفترة:</strong> " . formatDate($course['start_date']) . " - " . formatDate($course['end_date']) . "</p>
    <table border=\"1\" cellpadding=\"5\">
        <tr><th>الاسم</th><th>الأيام</th><th>الحاضر</th><th>النسبة</th></tr>";
    foreach ($report as $r) {
        $html .= "<tr>
            <td>{$r['name_ar']}</td>
            <td>{$r['total_days']}</td>
            <td>{$r['present_days']}</td>
            <td>{$r['attendance_pct']}%</td>
        </tr>";
    }
    $html .= "</table>";
    $pdf->writeHTML($html, true, false, true, false, '');
}

if (isset($history)) {
    $html = "<h2>السجل التدريبي</h2>
    <table border=\"1\" cellpadding=\"5\">
        <tr><th>الدورة</th><th>من</th><th>إلى</th><th>الدرجة</th><th>الحضور</th></tr>";
    foreach ($history as $h) {
        $html .= "<tr>
            <td>{$h['course_name']} #{$h['course_number']}</td>
            <td>" . formatDate($h['start_date']) . "</td>
            <td>" . formatDate($h['end_date']) . "</td>
            <td>" . ($h['final_grade'] ?: '-') . "</td>
            <td>{$h['attendance_percentage']}%</td>
        </tr>";
    }
    $html .= "</table>";
    $pdf->writeHTML($html, true, false, true, false, '');
}

if (isset($stats)) {
    $html = "<h2>إحصائيات الدورة</h2>
    <p><strong>عدد المتدربين:</strong> {$stats['total_trainees']}</p>
    <p><strong>متوسط الحضور:</strong> " . round($stats['avg_attendance'], 2) . "%</p>
    <p><strong>متوسط الدرجات:</strong> " . round($stats['avg_score'], 2) . "</p>";
    $pdf->writeHTML($html, true, false, true, false, '');
}

if (isset($logs)) {
    $html = "<h2>سجل النشاط</h2>
    <table border=\"1\" cellpadding=\"5\">
        <tr><th>الوقت</th><th>المستخدم</th><th>الإجراء</th><th>التفاصيل</th></tr>";
    foreach ($logs as $l) {
        $user = $l['username'] ?: ($l['trainee_name'] ?: 'نظام');
        $html .= "<tr>
            <td>" . date('Y-m-d H:i', strtotime($l['timestamp'])) . "</td>
            <td>$user</td>
            <td>{$l['action']}</td>
            <td>{$l['details']}</td>
        </tr>";
    }
    $html .= "</table>";
    $pdf->writeHTML($html, true, false, true, false, '');
}

// Output
$filename = preg_replace('/[^a-zA-Z0-9_-]/', '_', $title) . '.pdf';
$pdf->Output($filename, 'I');

logActivity($_SESSION['user_id'], null, 'report_export_pdf', $title);
?>