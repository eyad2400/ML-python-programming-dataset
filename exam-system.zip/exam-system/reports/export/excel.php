<?php
// reports/export/excel.php
require_once __DIR__ . '/../../vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$sheet->setRightToLeft(true);

// Example: Attendance
if (isset($report)) {
    $sheet->setTitle('الحضور');
    $sheet->fromArray(['الاسم', 'الأيام', 'الحاضر', 'النسبة'], null, 'A1');
    $row = 2;
    foreach ($report as $r) {
        $sheet->fromArray([
            $r['name_ar'],
            $r['total_days'],
            $r['present_days'],
            $r['attendance_pct'] . '%'
        ], null, "A$row");
        $row++;
    }
}

$filename = preg_replace('/[^a-zA-Z0-9_-]/', '_', $title) . '.xlsx';
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="' . $filename . '"');
$writer = new Xlsx($spreadsheet);
$writer->save('php://output');

logActivity($_SESSION['user_id'], null, 'report_export_excel', $title);
exit;
?>