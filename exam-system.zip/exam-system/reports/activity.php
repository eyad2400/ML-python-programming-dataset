<?php
require '../api/db.php';
requireAdmin();

$start = $_GET['start'] ?? date('Y-m-d', strtotime('-30 days'));
$end = $_GET['end'] ?? date('Y-m-d');

$pdo = getDB();
$logs = $pdo->query("
    SELECT l.*, u.username, et.name_ar as trainee_name
    FROM user_activity l
    LEFT JOIN users u ON l.user_id = u.id
    LEFT JOIN exam_takers et ON l.national_id = et.national_id
    WHERE DATE(l.timestamp) BETWEEN '$start' AND '$end'
    ORDER BY l.timestamp DESC
    LIMIT 1000
")->fetchAll();

$title = "سجل النشاط ($start إلى $end)";
include 'export/pdf.php';
?>