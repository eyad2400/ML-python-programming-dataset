<?php
require '../api/db.php';
requireStaff();

$course_id = (int)($_GET['course_id'] ?? 0);
if ($course_id <= 0) {
    die('Invalid course');
}

$pdo = getDB();

// Get course
$course = $pdo->query("SELECT name, course_number, start_date, end_date FROM training_courses WHERE id = $course_id")->fetch();
if (!$course) die('Course not found');

// Generate report
$report = $pdo->query("
    SELECT 
        et.national_id, et.name_ar,
        COUNT(ca.attendance_date) as total_days,
        SUM(ca.is_present) as present_days,
        ROUND(SUM(ca.is_present)/COUNT(ca.attendance_date)*100, 2) as attendance_pct
    FROM course_attendance ca
    JOIN exam_takers et ON ca.national_id = et.national_id
    WHERE ca.course_id = $course_id
    GROUP BY ca.national_id
    ORDER BY et.name_ar
")->fetchAll();

$generated_at = date('Y-m-d H:i');
$title = "تقرير الحضور - {$course['name']} #{$course['course_number']}";

include 'export/pdf.php'; // Default PDF
?>