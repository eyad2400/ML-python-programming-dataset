<?php
require '../api/db.php';
requireStaff();

$course_id = (int)($_GET['course_id'] ?? 0);
if ($course_id <= 0) die('Invalid');

$pdo = getDB();
$course = $pdo->query("SELECT * FROM training_courses WHERE id = $course_id")->fetch();

$stats = $pdo->query("
    SELECT 
        COUNT(DISTINCT cta.national_id) as total_trainees,
        AVG(att.attendance_pct) as avg_attendance,
        AVG(ea.score) as avg_score
    FROM course_trainee_assignments cta
    LEFT JOIN v_attendance_summary att ON att.national_id = cta.national_id AND att.course_id = $course_id
    LEFT JOIN exam_attempts ea ON ea.national_id = cta.national_id AND ea.course_id = $course_id
    WHERE cta.course_id = $course_id
")->fetch();

$title = "تقرير الدورة: {$course['name']} #{$course['course_number']}";
include 'export/pdf.php';
?>