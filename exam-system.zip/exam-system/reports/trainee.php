<?php
require '../api/db.php';
$national_id = $_GET['national_id'] ?? '';
if (!preg_match('/^\d{14}$/', $national_id)) {
    die('Invalid ID');
}

$pdo = getDB();
$trainee = $pdo->query("SELECT name_ar FROM exam_takers WHERE national_id = '$national_id'")->fetchColumn();
if (!$trainee) die('Trainee not found');

$history = $pdo->query("
    SELECT 
        tch.course_name, tch.course_number,
        tch.start_date, tch.end_date,
        tch.final_grade, tch.attendance_percentage
    FROM trainee_course_history tch
    WHERE tch.national_id = '$national_id'
    ORDER BY tch.end_date DESC
")->fetchAll();

$title = "ملف المتدرب: $trainee";
include 'export/pdf.php';
?>