// exam/assets/exam.js
// Reusable for portal & exam
// Empty or shared logic
// Already in main.js: get(), post(), toast(), formatDate()