// assets/js/exam-timer.js
function startExamTimer(durationMinutes, onEnd) {
  let seconds = durationMinutes * 60;
  const timerEl = document.getElementById('exam-timer');

  const interval = setInterval(() => {
    seconds--;
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    timerEl.textContent = `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;

    if (seconds <= 0) {
      clearInterval(interval);
      timerEl.textContent = 'انتهى الوقت!';
      if (onEnd) onEnd();
    }
  }, 1000);
}