// assets/js/main.js
function get(url) {
  return fetch(url, { credentials: 'include' }).then(r => r.json());
}

function post(url, data = {}) {
  return fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
    credentials: 'include'
  }).then(r => r.json());
}

function toast(msg, type = 'info') {
  const t = document.createElement('div');
  t.className = `toast toast-${type}`;
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 3000);
}

// Prevent all form reloads
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('form').forEach(f => f.addEventListener('submit', e => e.preventDefault()));
});