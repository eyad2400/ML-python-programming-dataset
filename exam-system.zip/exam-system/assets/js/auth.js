// assets/js/auth.js
async function checkSession() {
  const res = await fetch('../api/auth/check-session.php');
  const data = await res.json();
  if (!data.valid) {
    localStorage.removeItem('session_token');
    window.location.href = '../auth/login.html';
  }
  return data;
}

// Auto-check on dashboard pages
if (window.location.pathname.includes('dashboard')) {
  document.addEventListener('DOMContentLoaded', checkSession);
}