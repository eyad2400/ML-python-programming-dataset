// Use in exam pages: candidate-exam.html, trainee-exam.html
async function verifyExamToken() {
  const token = localStorage.getItem('exam_token');
  if (!token) return false;

  const res = await fetch('../api/auth/validate-exam-token.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ token })
  });

  const data = await res.json();
  if (!data.valid) {
    localStorage.removeItem('exam_token');
    alert('انتهت صلاحية الجلسة');
    location.href = '../index.html';
    return false;
  }
  return data;
}

// Call on page load
document.addEventListener('DOMContentLoaded', () => {
  verifyExamToken();
});