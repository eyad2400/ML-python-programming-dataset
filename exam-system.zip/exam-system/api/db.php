<?php
// api/db.php
require '../data/config.php';

session_start();
$pdo = $GLOBALS['pdo'];

function getDB() { global $pdo; return $pdo; }

function requireStaff() {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        exit(json_encode(['error' => 'Login required']));
    }
}

function requireSuperAdmin() {
    requireStaff();
    if (!$_SESSION['is_super_admin']) {
        http_response_code(403);
        exit(json_encode(['error' => 'Super Admin only']));
    }
}

function logActivity($user_id, $national_id, $action, $details = '') {
    $pdo = getDB();
    $stmt = $pdo->prepare("INSERT INTO user_activity (user_id, national_id, action, details, ip_address) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$user_id, $national_id, $action, $details, $_SERVER['REMOTE_ADDR'] ?? 'unknown']);
}
?>