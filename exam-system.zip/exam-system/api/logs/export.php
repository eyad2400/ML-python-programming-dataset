<?php
require '../db.php';
requireAdmin(); // Only Super Admin can export

$start_date = $_GET['start_date'] ?? '';
$end_date = $_GET['end_date'] ?? '';

$pdo = getDB();

$sql = "
    SELECT 
        l.timestamp, u.username, et.national_id, et.name_ar as trainee_name,
        l.action, l.details, l.ip_address
    FROM user_activity l
    LEFT JOIN users u ON l.user_id = u.id
    LEFT JOIN exam_takers et ON l.national_id = et.national_id
    WHERE 1=1
";
$params = [];

if ($start_date) {
    $sql .= " AND DATE(l.timestamp) >= ?";
    $params[] = $start_date;
}
if ($end_date) {
    $sql .= " AND DATE(l.timestamp) <= ?";
    $params[] = $end_date;
}

$sql .= " ORDER BY l.timestamp DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);

$filename = "activity-log-" . date('Y-m-d') . ".csv";
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');

$output = fopen('php://output', 'w');
fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF)); // BOM for Arabic Excel

// Header
fputcsv($output, [
    'التاريخ والوقت',
    'اسم المستخدم',
    'الرقم القومي',
    'اسم المتدرب',
    'الإجراء',
    'التفاصيل',
    'عنوان IP'
]);

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    fputcsv($output, [
        $row['timestamp'],
        $row['username'] ?? 'غير معروف',
        $row['national_id'] ?? '',
        $row['trainee_name'] ?? '',
        $row['action'],
        $row['details'] ?? '',
        $row['ip_address']
    ]);
}

logActivity($_SESSION['user_id'], null, 'export_logs', "From: $start_date, To: $end_date");
exit;
?>