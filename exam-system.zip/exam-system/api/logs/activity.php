<?php
require '../db.php';
requireStaff(); // Only staff can view logs

// Filters
$start_date = $_GET['start_date'] ?? '';
$end_date = $_GET['end_date'] ?? '';
$user_id = (int)($_GET['user_id'] ?? 0);
$national_id = $_GET['national_id'] ?? '';
$action = $_GET['action'] ?? '';
$limit = min((int)($_GET['limit'] ?? 100), 1000); // Max 1000
$offset = max((int)($_GET['offset'] ?? 0), 0);

$pdo = getDB();

$sql = "
    SELECT 
        l.id, l.user_id, u.username, u.name_ar as staff_name,
        l.national_id, et.name_ar as trainee_name,
        l.action, l.details, l.ip_address, l.timestamp
    FROM user_activity l
    LEFT JOIN users u ON l.user_id = u.id
    LEFT JOIN exam_takers et ON l.national_id = et.national_id
    WHERE 1=1
";
$params = [];

if ($start_date && preg_match('/^\d{4}-\d{2}-\d{2}$/', $start_date)) {
    $sql .= " AND DATE(l.timestamp) >= ?";
    $params[] = $start_date;
}
if ($end_date && preg_match('/^\d{4}-\d{2}-\d{2}$/', $end_date)) {
    $sql .= " AND DATE(l.timestamp) <= ?";
    $params[] = $end_date;
}
if ($user_id > 0) {
    $sql .= " AND l.user_id = ?";
    $params[] = $user_id;
}
if ($national_id && preg_match('/^\d{14}$/', $national_id)) {
    $sql .= " AND l.national_id = ?";
    $params[] = $national_id;
}
if ($action) {
    $sql .= " AND l.action LIKE ?";
    $params[] = "%$action%";
}

$sql .= " ORDER BY l.timestamp DESC LIMIT ? OFFSET ?";
$params[] = $limit;
$params[] = $offset;

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Total count for pagination
$count_stmt = $pdo->prepare("SELECT COUNT(*) FROM user_activity WHERE 1=1" . substr($sql, strpos($sql, 'WHERE') + 5, strpos($sql, 'ORDER BY') - strpos($sql, 'WHERE') - 5));
$count_stmt->execute(array_slice($params, 0, count($params) - 2));
$total = $count_stmt->fetchColumn();

echo json_encode([
    'logs' => $logs,
    'total' => (int)$total,
    'limit' => $limit,
    'offset' => $offset
], JSON_UNESCAPED_UNICODE);
?>