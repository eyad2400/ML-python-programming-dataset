<?php
require '../db.php';
requireAdmin(); // Only Super Admin

$days = (int)($_POST['days'] ?? 0);
if ($days < 30) {
    echo json_encode(['error' => 'الحد الأدنى 30 يومًا']);
    exit;
}

$pdo = getDB();
$cutoff = date('Y-m-d H:i:s', strtotime("-$days days"));

$stmt = $pdo->prepare("DELETE FROM user_activity WHERE timestamp < ?");
$count = $stmt->execute([$cutoff]) ? $stmt->rowCount() : 0;

logActivity($_SESSION['user_id'], null, 'clear_logs', "Deleted: $count records older than $days days");

echo json_encode([
    'success' => true,
    'deleted' => $count,
    'message' => "تم حذف $count سجل أقدم من $days يومًا"
]);
?>