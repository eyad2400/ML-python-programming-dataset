<?php
require '../db.php';
$national_id = $_GET['national_id'] ?? '';

if (!preg_match('/^\d{14}$/', $national_id)) {
    echo json_encode(['error' => 'رقم قومي غير صالح']);
    exit;
}

$pdo = getDB();

// Basic info
$trainee = $pdo->query("
    SELECT et.*, u.name_ar as added_by_name 
    FROM exam_takers et 
    LEFT JOIN users u ON et.added_by = u.id 
    WHERE et.national_id = '$national_id'
")->fetch(PDO::FETCH_ASSOC);

if (!$trainee) {
    echo json_encode(['error' => 'المتدرب غير موجود']);
    exit;
}

// Course history
$history = $pdo->query("
    SELECT 
        tch.course_name, tch.course_number, tch.start_date, tch.end_date,
        tch.final_grade, tch.attendance_percentage
    FROM trainee_course_history tch
    WHERE tch.national_id = '$national_id'
    ORDER BY tch.end_date DESC
")->fetchAll();

// Current courses
$current = $pdo->query("
    SELECT c.name, c.course_number, c.start_date, c.end_date
    FROM training_courses c
    JOIN course_trainee_assignments cta ON c.id = cta.course_id
    WHERE cta.national_id = '$national_id' AND c.end_date >= CURDATE()
")->fetchAll();

echo json_encode([
    'trainee' => $trainee,
    'history' => $history,
    'current_courses' => $current
], JSON_UNESCAPED_UNICODE);
?>