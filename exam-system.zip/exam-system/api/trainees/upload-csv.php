<?php
require '../db.php';
requireStaff();

if (!isset($_FILES['csv_file']) || $_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(['error' => 'فشل رفع الملف']);
    exit;
}

$file = $_FILES['csv_file']['tmp_name'];
$handle = fopen($file, 'r');
if (!$handle) {
    echo json_encode(['error' => 'لا يمكن قراءة الملف']);
    exit;
}

$pdo = getDB();
$pdo->beginTransaction();

$added = 0;
$errors = [];
$line = 0;

while (($row = fgetcsv($handle)) !== false) {
    $line++;
    if ($line == 1) continue; // Skip header

    $national_id = preg_replace('/\D/', '', $row[0] ?? '');
    $name_ar = trim($row[1] ?? '');

    if (!preg_match('/^\d{14}$/', $national_id) || !$name_ar) {
        $errors[] = "سطر $line: بيانات غير صالحة";
        continue;
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO exam_takers (national_id, name_ar, user_type, added_by) VALUES (?, ?, 'trainee', ?)");
        $stmt->execute([$national_id, $name_ar, $_SESSION['user_id']]);
        $added++;
    } catch (PDOException $e) {
        $errors[] = "سطر $line: $national_id موجود";
    }
}

if ($added > 0) {
    $pdo->commit();
    logActivity($_SESSION['user_id'], null, 'csv_upload_trainees', "Added: $added");
} else {
    $pdo->rollBack();
}

fclose($handle);

echo json_encode([
    'success' => $added > 0,
    'added' => $added,
    'errors' => $errors
], JSON_UNESCAPED_UNICODE);
?>