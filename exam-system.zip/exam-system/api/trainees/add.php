<?php
require '../db.php';
requireStaff(); // Only staff can add

$data = json_decode(file_get_contents('php://input'), true);

$national_id = preg_replace('/\D/', '', $data['national_id'] ?? '');
$name_ar = trim($data['name_ar'] ?? '');
$user_type = $data['user_type'] ?? 'trainee'; // 'trainee' or 'candidate'

if (!preg_match('/^\d{14}$/', $national_id) || !$name_ar || !in_array($user_type, ['trainee', 'candidate'])) {
    echo json_encode(['error' => 'بيانات غير صالحة']);
    exit;
}

$pdo = getDB();

try {
    $stmt = $pdo->prepare("
        INSERT INTO exam_takers 
        (national_id, name_ar, user_type, added_by) 
        VALUES (?, ?, ?, ?)
    ");
    $stmt->execute([$national_id, $name_ar, $user_type, $_SESSION['user_id']]);

    logActivity($_SESSION['user_id'], $national_id, 'add_trainee', "Name: $name_ar, Type: $user_type");

    echo json_encode([
        'success' => true,
        'national_id' => $national_id,
        'message' => "تم إضافة: $name_ar"
    ]);
} catch (PDOException $e) {
    if ($e->getCode() == 23000) {
        echo json_encode(['error' => 'الرقم القومي موجود مسبقًا']);
    } else {
        error_log("Trainee add error: " . $e->getMessage());
        echo json_encode(['error' => 'فشل في الإضافة']);
    }
}
?>