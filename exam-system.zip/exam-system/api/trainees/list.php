<?php
require '../db.php';

// Filters
$search = $_GET['search'] ?? '';
$course_id = (int)($_GET['course_id'] ?? 0);
$user_type = $_GET['user_type'] ?? ''; // trainee or candidate
$limit = min((int)($_GET['limit'] ?? 50), 500);
$offset = max((int)($_GET['offset'] ?? 0), 0);

$pdo = getDB();

$sql = "
    SELECT 
        et.id, et.national_id, et.name_ar, et.user_type, et.added_at,
        u.name_ar as added_by_name,
        c.name as course_name, c.course_number
    FROM exam_takers et
    LEFT JOIN users u ON et.added_by = u.id
    LEFT JOIN course_trainee_assignments cta ON et.national_id = cta.national_id
    LEFT JOIN training_courses c ON cta.course_id = c.id
    WHERE 1=1
";
$params = [];

if ($search) {
    $sql .= " AND (et.national_id LIKE ? OR et.name_ar LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}
if ($course_id > 0) {
    $sql .= " AND cta.course_id = ?";
    $params[] = $course_id;
}
if (in_array($user_type, ['trainee', 'candidate'])) {
    $sql .= " AND et.user_type = ?";
    $params[] = $user_type;
}

$sql .= " ORDER BY et.added_at DESC LIMIT ? OFFSET ?";
$params[] = $limit;
$params[] = $offset;

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$trainees = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($trainees, JSON_UNESCAPED_UNICODE);
?>