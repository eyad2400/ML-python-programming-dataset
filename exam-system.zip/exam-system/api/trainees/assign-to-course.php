<?php
require '../db.php';
requireStaff();

$data = json_decode(file_get_contents('php://input'), true);

$course_id = (int)($data['course_id'] ?? 0);
$national_id = $data['national_id'] ?? '';

if ($course_id <= 0 || !preg_match('/^\d{14}$/', $national_id)) {
    echo json_encode(['error' => 'بيانات غير صالحة']);
    exit;
}

$pdo = getDB();

// Validate
$course = $pdo->query("SELECT 1 FROM training_courses WHERE id = $course_id")->fetch();
$trainee = $pdo->query("SELECT 1 FROM exam_takers WHERE national_id = '$national_id' AND user_type = 'trainee'")->fetch();

if (!$course || !$trainee) {
    echo json_encode(['error' => 'الدورة أو المتدرب غير موجود']);
    exit;
}

$exists = $pdo->query("SELECT 1 FROM course_trainee_assignments WHERE course_id = $course_id AND national_id = '$national_id'")->fetch();
if ($exists) {
    echo json_encode(['error' => 'مسجل مسبقًا في الدورة']);
    exit;
}

$stmt = $pdo->prepare("INSERT INTO course_trainee_assignments (course_id, national_id) VALUES (?, ?)");
$stmt->execute([$course_id, $national_id]);

logActivity($_SESSION['user_id'], $national_id, 'assign_to_course', "Course ID: $course_id");

echo json_encode(['success' => true, 'message' => 'تم التسجيل في الدورة']);
?>