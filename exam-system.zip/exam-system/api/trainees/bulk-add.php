<?php
require '../db.php';
requireStaff();

$data = json_decode(file_get_contents('php://input'), true);
if (!is_array($data)) {
    echo json_encode(['error' => 'يجب إرسال مصفوفة JSON']);
    exit;
}

$pdo = getDB();
$pdo->beginTransaction();

$added = 0;
$errors = [];

foreach ($data as $i => $item) {
    $national_id = preg_replace('/\D/', '', $item['national_id'] ?? '');
    $name_ar = trim($item['name_ar'] ?? '');
    $user_type = $item['user_type'] ?? 'trainee';

    if (!preg_match('/^\d{14}$/', $national_id) || !$name_ar) {
        $errors[] = "صف $i: بيانات غير صالحة";
        continue;
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO exam_takers (national_id, name_ar, user_type, added_by) VALUES (?, ?, ?, ?)");
        $stmt->execute([$national_id, $name_ar, $user_type, $_SESSION['user_id']]);
        $added++;
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) {
            $errors[] = "صف $i: $national_id موجود مسبقًا";
        }
    }
}

if ($added > 0) {
    $pdo->commit();
    logActivity($_SESSION['user_id'], null, 'bulk_add_trainees', "Added: $added");
} else {
    $pdo->rollBack();
}

echo json_encode([
    'success' => $added > 0,
    'added' => $added,
    'errors' => $errors
], JSON_UNESCAPED_UNICODE);
?>