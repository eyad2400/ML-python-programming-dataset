<?php
// api/auth/logout.php
session_start();
$user_id = $_SESSION['user_id'] ?? null;
if ($user_id) logActivity($user_id, null, 'logout');
session_destroy();
echo json_encode(['success' => true]);
?>