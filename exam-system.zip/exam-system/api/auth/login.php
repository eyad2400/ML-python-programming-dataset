<?php
// api/auth/login.php
require '../db.php';

$data = json_decode(file_get_contents('php://input'), true);
$username = $data['username'] ?? '';
$password = $data['password'] ?? '';

$pdo = getDB();
$stmt = $pdo->prepare("SELECT id, password_hash, name_ar, role, is_super_admin FROM users WHERE username = ?");
$stmt->execute([$username]);
$user = $stmt->fetch();

if ($user && password_verify($password, $user['password_hash'])) {
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['name_ar'] = $user['name_ar'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['is_super_admin'] = $user['is_super_admin'];
    logActivity($user['id'], null, 'login');
    echo json_encode(['success' => true, 'name' => $user['name_ar']]);
} else {
    echo json_encode(['error' => 'بيانات غير صحيحة']);
}
?>