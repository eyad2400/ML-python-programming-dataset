<?php
require '../api/db.php';

if (!isset($_SESSION['user_id'])) {
  echo json_encode(['valid' => false]);
  exit;
}

// Session timeout: 2 hours
if (time() - $_SESSION['login_time'] > 7200) {
  session_destroy();
  echo json_encode(['valid' => false, 'error' => 'انتهت الجلسة']);
  exit;
}

// IP lock
if ($_SESSION['ip'] !== ($_SERVER['REMOTE_ADDR'] ?? '')) {
  logActivity($_SESSION['user_id'], null, 'session_ip_mismatch');
  session_destroy();
  echo json_encode(['valid' => false, 'error' => 'تغيير عنوان IP']);
  exit;
}

echo json_encode([
  'valid' => true,
  'user_id' => $_SESSION['user_id'],
  'username' => $_SESSION['username'],
  'role' => $_SESSION['role'],
  'is_super_admin' => $_SESSION['is_super_admin'],
  'csrf_token' => $_SESSION['csrf_token']
]);
?>