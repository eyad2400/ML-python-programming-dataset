<?php
require '../db.php';

$data = json_decode(file_get_contents('php://input'), true);
$token = $data['token'] ?? '';

$pdo = getDB();
$stmt = $pdo->prepare("SELECT * FROM exam_sessions WHERE token = ? AND expires_at > NOW()");
$stmt->execute([$token]);
$session = $stmt->fetch();

if (!$session) {
  echo json_encode(['valid' => false]);
  exit;
}

echo json_encode([
  'valid' => true,
  'national_id' => $session['national_id'],
  'user_type' => $session['user_type']
]);
?>