<?php
// api/auth/check.php
session_start();
echo json_encode([
  'logged_in' => isset($_SESSION['user_id']),
  'is_super_admin' => $_SESSION['is_super_admin'] ?? false
]);
?>