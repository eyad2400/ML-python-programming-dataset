<?php
require '../api/db.php';

$data = json_decode(file_get_contents('php://input'), true);
$national_id = $data['national_id'] ?? '';
$user_type = $data['user_type'] ?? 'candidate';

if (!preg_match('/^\d{14}$/', $national_id)) {
  echo json_encode(['error' => 'الرقم القومي غير صالح']);
  exit;
}

$pdo = getDB();

// Check if exists
$stmt = $pdo->prepare("SELECT * FROM exam_takers WHERE national_id = ? AND user_type = ?");
$stmt->execute([$national_id, $user_type]);
$user = $stmt->fetch();

if (!$user) {
  echo json_encode(['error' => 'الرقم غير مسجل كـ' . ($user_type === 'candidate' ? 'مرشح' : 'متدرب')]);
  exit;
}

// Generate exam token (valid 2 hours)
$token = bin2hex(random_bytes(32));
$expires = date('Y-m-d H:i:s', strtotime('+2 hours'));

$stmt = $pdo->prepare("INSERT INTO exam_sessions (national_id, token, expires_at, user_type) VALUES (?, ?, ?, ?)");
$stmt->execute([$national_id, $token, $expires, $user_type]);

logActivity(null, $national_id, 'exam_login', "Type: $user_type");

echo json_encode([
  'success' => true,
  'token' => $token,
  'name' => $user['name_ar']
]);
?>