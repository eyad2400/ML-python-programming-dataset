<?php
// api/backup/list-backups.php
// List all backup files from USB drive (D:\ExamBackups)
// Super Admin only

require '../db.php';
requireSuperAdmin();

header('Content-Type: application/json; charset=utf-8');

$backup_dir = 'D:/ExamBackups';
$backups = [];

if (!is_dir($backup_dir)) {
    echo json_encode(['backups' => []], JSON_UNESCAPED_UNICODE);
    exit;
}

$files = glob($backup_dir . '/backup_*.zip');
usort($files, function($a, $b) {
    return filemtime($b) - filemtime($a);
});

foreach ($files as $file) {
    $filename = basename($file);
    $size = filesize($file);
    $date = date('Y-m-d H:i', filemtime($file));
    $backups[] = [
        'filename' => $filename,
        'size' => formatBytes($size),
        'date' => $date,
        'path' => $file
    ];
}

echo json_encode(['backups' => $backups], JSON_UNESCAPED_UNICODE);

function formatBytes($bytes) {
    $units = ['B', 'KB', 'MB', 'GB'];
    $i = 0;
    while ($bytes >= 1024 && $i < count($units) - 1) {
        $bytes /= 1024;
        $i++;
    }
    return round($bytes, 2) . ' ' . $units[$i];
}
?>