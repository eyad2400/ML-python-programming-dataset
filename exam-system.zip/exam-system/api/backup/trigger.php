<?php
require '../db.php';
requireSuperAdmin();

$pdo = getDB();

// Check if 30 days passed
$last = $pdo->query("SELECT MAX(timestamp) FROM backup_log")->fetchColumn();
if ($last && strtotime($last) > strtotime('-30 days')) {
    echo json_encode(['error' => 'النسخ الاحتياطي يحدث كل 30 يوم']);
    exit;
}

// Backup DB
$db_backup = 'backup_' . date('Y-m-d_H-i') . '.sql';
exec("mysqldump -u root exam_system > /tmp/$db_backup");

// Log
$stmt = $pdo->prepare("INSERT INTO backup_log (backup_file, created_by) VALUES (?, ?)");
$stmt->execute([$db_backup, $_SESSION['user_id']]);

logActivity($_SESSION['user_id'], null, 'manual_backup', $db_backup);

echo json_encode(['success' => true, 'file' => $db_backup]);
?>