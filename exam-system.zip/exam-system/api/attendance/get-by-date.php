<?php
require '../db.php';
requireStaff();

$course_id = (int)($_GET['course_id'] ?? 0);
$date = $_GET['date'] ?? '';

if ($course_id <= 0 || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
    echo json_encode(['error' => 'بيانات غير صالحة']);
    exit;
}

$pdo = getDB();

// Get enrolled trainees
$trainees = $pdo->query("
    SELECT et.national_id, et.name_ar
    FROM exam_takers et
    JOIN course_trainee_assignments cta ON et.national_id = cta.national_id
    WHERE cta.course_id = $course_id
    ORDER BY et.name_ar
")->fetchAll();

// Get attendance for this date
$attendance = $pdo->query("
    SELECT national_id, is_present, marked_by, marked_at
    FROM course_attendance
    WHERE course_id = $course_id AND attendance_date = '$date'
")->fetchAll(PDO::FETCH_KEY_PAIR);

// Merge
$result = array_map(function($t) use ($attendance) {
    $t['is_present'] = $attendance[$t['national_id']]['is_present'] ?? null;
    $t['marked_by'] = $attendance[$t['national_id']]['marked_by'] ?? null;
    $t['marked_at'] = $attendance[$t['national_id']]['marked_at'] ?? null;
    return $t;
}, $trainees);

echo json_encode($result, JSON_UNESCAPED_UNICODE);
?>