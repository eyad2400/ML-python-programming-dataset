<?php
require '../db.php';
requireStaff(); // Ensures only logged-in staff can mark

$data = json_decode(file_get_contents('php://input'), true);

// Required fields
$course_id = (int)($data['course_id'] ?? 0);
$national_id = $data['national_id'] ?? '';
$attendance_date = $data['attendance_date'] ?? ''; // YYYY-MM-DD
$is_present = (bool)($data['is_present'] ?? false);

if ($course_id <= 0 || !preg_match('/^\d{14}$/', $national_id) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $attendance_date)) {
    echo json_encode(['error' => 'بيانات غير صالحة']);
    exit;
}

// Validate date is within course period
$pdo = getDB();
$course = $pdo->query("SELECT start_date, end_date FROM training_courses WHERE id = $course_id")->fetch();
if (!$course || $attendance_date < $course['start_date'] || $attendance_date > $course['end_date']) {
    echo json_encode(['error' => 'التاريخ خارج نطاق الدورة']);
    exit;
}

// Check if trainee is enrolled
$enrolled = $pdo->query("
    SELECT 1 FROM course_trainee_assignments 
    WHERE course_id = $course_id AND national_id = '$national_id'
")->fetch();
if (!$enrolled) {
    echo json_encode(['error' => 'المتدرب غير مسجل في الدورة']);
    exit;
}

// Mark attendance (INSERT or UPDATE)
$stmt = $pdo->prepare("
    INSERT INTO course_attendance 
    (course_id, national_id, attendance_date, is_present, marked_by, marked_at)
    VALUES (?, ?, ?, ?, ?, NOW())
    ON DUPLICATE KEY UPDATE 
    is_present = VALUES(is_present), 
    marked_by = VALUES(marked_by), 
    marked_at = NOW()
");
$stmt->execute([$course_id, $national_id, $attendance_date, $is_present ? 1 : 0, $_SESSION['user_id']]);

logActivity($_SESSION['user_id'], $national_id, 'mark_attendance', 
    "Course: $course_id, Date: $attendance_date, Present: " . ($is_present ? 'Yes' : 'No'));

echo json_encode(['success' => true, 'message' => 'تم تسجيل الحضور']);
?>