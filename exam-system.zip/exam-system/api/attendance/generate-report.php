<?php
require '../db.php';
requireStaff();

$course_id = (int)($_GET['course_id'] ?? 0);
if ($course_id <= 0) {
    echo json_encode(['error' => 'معرف الدورة مطلوب']);
    exit;
}

$pdo = getDB();

// Get course info
$course = $pdo->query("SELECT name, course_number, start_date, end_date FROM training_courses WHERE id = $course_id")->fetch();
if (!$course) {
    echo json_encode(['error' => 'الدورة غير موجودة']);
    exit;
}

// Get trainees and attendance stats
$report = $pdo->query("
    SELECT 
        et.national_id,
        et.name_ar,
        COUNT(ca.attendance_date) as total_days,
        SUM(ca.is_present) as present_days,
        ROUND(SUM(ca.is_present) / COUNT(ca.attendance_date) * 100, 2) as attendance_percentage
    FROM exam_takers et
    JOIN course_trainee_assignments cta ON et.national_id = cta.national_id
    LEFT JOIN course_attendance ca ON ca.national_id = et.national_id AND ca.course_id = $course_id
    WHERE cta.course_id = $course_id
    GROUP BY et.national_id, et.name_ar
    ORDER BY attendance_percentage DESC, et.name_ar
")->fetchAll();

echo json_encode([
    'course' => $course,
    'report' => $report,
    'generated_at' => date('Y-m-d H:i:s')
], JSON_UNESCAPED_UNICODE);
?>