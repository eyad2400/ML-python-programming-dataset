<?php
require '../db.php';
$national_id = $_GET['national_id'] ?? '';

if (!preg_match('/^\d{14}$/', $national_id)) {
    echo json_encode(['error' => 'رقم قومي غير صالح']);
    exit;
}

$pdo = getDB();

$history = $pdo->query("
    SELECT 
        c.name as course_name,
        c.course_number,
        ca.attendance_date,
        ca.is_present,
        u.name_ar as marked_by
    FROM course_attendance ca
    JOIN training_courses c ON ca.course_id = c.id
    LEFT JOIN users u ON ca.marked_by = u.id
    WHERE ca.national_id = '$national_id'
    ORDER BY ca.attendance_date DESC
")->fetchAll();

echo json_encode($history, JSON_UNESCAPED_UNICODE);
?>