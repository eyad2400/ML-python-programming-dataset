<?php
// api/exam/submit.php
require '../db.php';

header('Content-Type: application/json; charset=utf-8');

$data = json_decode(file_get_contents('php://input'), true);
$exam_id = (int)($data['exam_id'] ?? 0);
$token = $data['token'] ?? '';
$answers = $data['answers'] ?? [];

if ($exam_id <= 0 || !$token || !is_array($answers)) {
    echo json_encode(['error' => 'Invalid data']);
    exit;
}

$pdo = getDB();

// Validate token
$stmt = $pdo->prepare("SELECT national_id FROM exam_sessions WHERE token = ? AND expires_at > NOW()");
$stmt->execute([$token]);
$session = $stmt->fetch();

if (!$session) {
    echo json_encode(['error' => 'Session expired']);
    exit;
}

$national_id = $session['national_id'];

// Get correct answers
$stmt = $pdo->prepare("SELECT question_id, correct_option FROM exam_questions WHERE exam_id = ?");
$stmt->execute([$exam_id]);
$correct = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

$score = 0;
$total = count($correct);

foreach ($correct as $qid => $correct_idx) {
    if (isset($answers[$qid]) && $answers[$qid] == $correct_idx) {
        $score++;
    }
}

$percentage = $total > 0 ? round(($score / $total) * 100, 2) : 0;

// Update attempt
$stmt = $pdo->prepare("
    UPDATE exam_attempts 
    SET end_time = NOW(), score = ?, total_questions = ?, correct_answers = ?
    WHERE exam_id = ? AND national_id = ? AND attempt_date = CURDATE()
");
$stmt->execute([$percentage, $total, $score, $exam_id, $national_id]);

// Get details
$stmt = $pdo->prepare("
    SELECT c.name as course_name, c.course_number, s.name as subject_name
    FROM exams e
    JOIN subjects s ON e.subject_id = s.id
    JOIN course_subjects cs ON s.id = cs.subject_id
    JOIN training_courses c ON cs.course_id = c.id
    WHERE e.id = ?
");
$stmt->execute([$exam_id]);
$exam = $stmt->fetch();

logActivity(null, $national_id, 'exam_submitted', "Score: $percentage% ($score/$total)");

echo json_encode([
    'score' => $percentage,
    'correct' => $score,
    'total' => $total,
    'passed' => $percentage >= 70,
    'trainee_name' => $pdo->query("SELECT name_ar FROM exam_takers WHERE national_id = '$national_id'")->fetchColumn(),
    'course_name' => $exam['course_name'],
    'course_number' => $exam['course_number'],
    'subject_name' => $exam['subject_name'],
    'attempt_date' => date('Y-m-d')
], JSON_UNESCAPED_UNICODE);
?>