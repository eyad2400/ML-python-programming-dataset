<?php
// api/exam/generate-token.php
require '../db.php';

header('Content-Type: application/json; charset=utf-8');

$data = json_decode(file_get_contents('php://input'), true);
$national_id = preg_replace('/\D/', '', $data['national_id'] ?? '');

if (!preg_match('/^\d{14}$/', $national_id)) {
    echo json_encode(['error' => 'رقم قومي غير صالح']);
    exit;
}

$pdo = getDB();

// Validate trainee
$stmt = $pdo->prepare("SELECT id, name_ar, user_type FROM exam_takers WHERE national_id = ?");
$stmt->execute([$national_id]);
$trainee = $stmt->fetch();

if (!$trainee) {
    echo json_encode(['error' => 'المتدرب غير موجود']);
    exit;
}

// Check active course
$stmt = $pdo->prepare("
    SELECT c.id, c.name, c.course_number 
    FROM training_courses c
    JOIN course_trainee_assignments cta ON c.id = cta.course_id
    WHERE cta.national_id = ? AND c.end_date >= CURDATE()
");
$stmt->execute([$national_id]);
$course = $stmt->fetch();

if (!$course) {
    echo json_encode(['error' => 'لا توجد دورة نشطة']);
    exit;
}

// Generate token
$token = bin2hex(random_bytes(32));
$expires = date('Y-m-d H:i:s', time() + 1800); // 30 min

$stmt = $pdo->prepare("
    INSERT INTO exam_sessions (national_id, token, user_type, expires_at)
    VALUES (?, ?, ?, ?)
    ON DUPLICATE KEY UPDATE token = ?, expires_at = ?
");
$stmt->execute([
    $national_id, $token, $trainee['user_type'], $expires,
    $token, $expires
]);

logActivity(null, $national_id, 'exam_token_generated', "Course: {$course['name']} #{$course['course_number']}");

echo json_encode([
    'success' => true,
    'token' => $token,
    'expires_in' => 1800
], JSON_UNESCAPED_UNICODE);
?>