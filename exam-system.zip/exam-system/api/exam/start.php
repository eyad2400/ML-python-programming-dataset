<?php
// api/exam/start.php
require '../db.php';

header('Content-Type: application/json; charset=utf-8');

$exam_id = (int)($_GET['exam_id'] ?? 0);
$token = $_GET['token'] ?? '';

if ($exam_id <= 0 || !$token) {
    echo json_encode(['error' => 'Invalid request']);
    exit;
}

$pdo = getDB();

// Validate token
$stmt = $pdo->prepare("SELECT national_id FROM exam_sessions WHERE token = ? AND expires_at > NOW()");
$stmt->execute([$token]);
$session = $stmt->fetch();

if (!$session) {
    echo json_encode(['error' => 'Token expired']);
    exit;
}

$national_id = $session['national_id'];

// Get exam
$stmt = $pdo->prepare("
    SELECT e.*, c.name as course_name, c.course_number, s.name as subject_name
    FROM exams e
    JOIN subjects s ON e.subject_id = s.id
    JOIN course_subjects cs ON s.id = cs.subject_id
    JOIN training_courses c ON cs.course_id = c.id
    WHERE e.id = ?
");
$stmt->execute([$exam_id]);
$exam = $stmt->fetch();

if (!$exam) {
    echo json_encode(['error' => 'Exam not found']);
    exit;
}

// Mark attendance
$stmt = $pdo->prepare("
    INSERT IGNORE INTO course_attendance 
    (course_id, national_id, attendance_date, is_present, marked_by, marked_at)
    VALUES (?, ?, CURDATE(), 1, 
     (SELECT created_by FROM training_courses WHERE id = ? LIMIT 1), NOW())
");
$stmt->execute([$exam['course_id'], $national_id, $exam['course_id']]);

// Log attempt
$stmt = $pdo->prepare("
    INSERT INTO exam_attempts 
    (exam_id, national_id, course_id, attempt_date, start_time)
    VALUES (?, ?, ?, CURDATE(), NOW())
    ON DUPLICATE KEY UPDATE start_time = NOW()
");
$stmt->execute([$exam_id, $national_id, $exam['course_id']]);

logActivity(null, $national_id, 'exam_started', "Exam ID: $exam_id");

// Load questions (random)
$stmt = $pdo->prepare("
    SELECT id, question_text, option_a, option_b, option_c, option_d
    FROM exam_questions 
    WHERE exam_id = ? 
    ORDER BY RAND()
");
$stmt->execute([$exam_id]);
$questions = $stmt->fetchAll();

$questions = array_map(function($q) {
    return [
        'id' => $q['id'],
        'question_text' => $q['question_text'],
        'options' => [$q['option_a'], $q['option_b'], $q['option_c'], $q['option_d']]
    ];
}, $questions);

echo json_encode([
    'success' => true,
    'exam_id' => $exam_id,
    'course_name' => $exam['course_name'],
    'course_number' => $exam['course_number'],
    'subject_name' => $exam['subject_name'],
    'duration_minutes' => $exam['duration_minutes'],
    'questions' => $questions
], JSON_UNESCAPED_UNICODE);
?>