<?php
// api/exam/portal.php
require '../db.php';

header('Content-Type: application/json; charset=utf-8');

$token = $_GET['token'] ?? '';
if (!$token) {
    echo json_encode(['valid' => false, 'error' => 'Token missing']);
    exit;
}

$pdo = getDB();

// Validate token
$stmt = $pdo->prepare("
    SELECT es.national_id, es.user_type, et.name_ar 
    FROM exam_sessions es 
    JOIN exam_takers et ON es.national_id = et.national_id 
    WHERE es.token = ? AND es.expires_at > NOW()
");
$stmt->execute([$token]);
$session = $stmt->fetch();

if (!$session) {
    echo json_encode(['valid' => false, 'error' => 'Token expired or invalid']);
    exit;
}

$national_id = $session['national_id'];

// Get exams
$stmt = $pdo->prepare("
    SELECT 
        e.id as exam_id,
        c.id as course_id, c.name as course_name, c.course_number,
        s.id as subject_id, s.name as subject_name, s.duration_minutes,
        (SELECT COUNT(*) FROM exam_questions WHERE exam_id = e.id) as question_count,
        COALESCE(ea.score, 0) > 0 as attempted
    FROM exams e
    JOIN course_subjects cs ON e.subject_id = cs.subject_id
    JOIN training_courses c ON cs.course_id = c.id
    JOIN subjects s ON e.subject_id = s.id
    LEFT JOIN exam_attempts ea ON ea.exam_id = e.id AND ea.national_id = ?
    JOIN course_trainee_assignments cta ON c.id = cta.course_id AND cta.national_id = ?
    WHERE c.end_date >= CURDATE()
    ORDER BY c.start_date DESC
");
$stmt->execute([$national_id, $national_id]);
$exams = $stmt->fetchAll();

echo json_encode([
    'valid' => true,
    'trainee' => [
        'name_ar' => $session['name_ar'],
        'national_id' => $national_id
    ],
    'exams' => $exams
], JSON_UNESCAPED_UNICODE);
?>