<?php
// api/exam/get-result.php
require '../db.php';

header('Content-Type: application/json; charset=utf-8');

$national_id = $_GET['national_id'] ?? '';
$exam_id = (int)($_GET['exam_id'] ?? 0);

if (!preg_match('/^\d{14}$/', $national_id) || $exam_id <= 0) {
    echo json_encode(['error' => 'Invalid']);
    exit;
}

$pdo = getDB();

$stmt = $pdo->prepare("
    SELECT 
        ea.score, ea.attempt_date,
        et.name_ar,
        c.name as course_name, c.course_number,
        s.name as subject_name
    FROM exam_attempts ea
    JOIN exam_takers et ON ea.national_id = et.national_id
    JOIN exams e ON ea.exam_id = e.id
    JOIN subjects s ON e.subject_id = s.id
    JOIN course_subjects cs ON s.id = cs.subject_id
    JOIN training_courses c ON cs.course_id = c.id
    WHERE ea.national_id = ? AND ea.exam_id = ?
");
$stmt->execute([$national_id, $exam_id]);
$result = $stmt->fetch();

if (!$result) {
    echo json_encode(['error' => 'No result']);
    exit;
}

echo json_encode($result, JSON_UNESCAPED_UNICODE);
?>