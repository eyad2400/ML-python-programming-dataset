<?php
require '../db.php';
requireStaff();

$data = json_decode(file_get_contents('php://input'), true);

$course_id = (int)($data['course_id'] ?? 0);
$subject_id = (int)($data['subject_id'] ?? 0);

if ($course_id <= 0 || $subject_id <= 0) {
    echo json_encode(['error' => 'معرفات غير صالحة']);
    exit;
}

$pdo = getDB();

// Validate course and subject exist
$course = $pdo->query("SELECT 1 FROM training_courses WHERE id = $course_id")->fetch();
$subject = $pdo->query("SELECT 1 FROM subjects WHERE id = $subject_id")->fetch();

if (!$course || !$subject) {
    echo json_encode(['error' => 'الدورة أو المادة غير موجودة']);
    exit;
}

// Prevent duplicate
$exists = $pdo->query("SELECT 1 FROM course_subjects WHERE course_id = $course_id AND subject_id = $subject_id")->fetch();
if ($exists) {
    echo json_encode(['error' => 'المادة مضافة مسبقًا للدورة']);
    exit;
}

$stmt = $pdo->prepare("INSERT INTO course_subjects (course_id, subject_id) VALUES (?, ?)");
$stmt->execute([$course_id, $subject_id]);

logActivity($_SESSION['user_id'], null, 'assign_subject_to_course', 
    "Course: $course_id, Subject: $subject_id");

echo json_encode(['success' => true, 'message' => 'تم الربط']);
?>