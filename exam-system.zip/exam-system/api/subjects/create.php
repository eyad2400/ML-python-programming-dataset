<?php
require '../db.php';
requireStaff(); // Only staff can create

$data = json_decode(file_get_contents('php://input'), true);

$name = trim($data['name'] ?? '');
$code = strtoupper(trim($data['code'] ?? ''));
$duration_minutes = (int)($data['duration_minutes'] ?? 60);
$description = trim($data['description'] ?? '');

if (!$name || !$code || $duration_minutes < 15 || $duration_minutes > 480) {
    echo json_encode(['error' => 'بيانات غير صالحة']);
    exit;
}

if (!preg_match('/^[A-Z0-9]{3,10}$/', $code)) {
    echo json_encode(['error' => 'الكود يجب أن يكون أحرف/أرقام (3-10)']);
    exit;
}

$pdo = getDB();

try {
    $stmt = $pdo->prepare("
        INSERT INTO subjects (name, code, duration_minutes, description)
        VALUES (?, ?, ?, ?)
    ");
    $stmt->execute([$name, $code, $duration_minutes, $description]);
    $subject_id = $pdo->lastInsertId();

    logActivity($_SESSION['user_id'], null, 'create_subject', "Name: $name, Code: $code");

    echo json_encode([
        'success' => true,
        'subject_id' => $subject_id,
        'message' => "تم إنشاء المادة: $name"
    ]);
} catch (PDOException $e) {
    if ($e->getCode() == 23000) {
        echo json_encode(['error' => 'الكود أو الاسم موجود مسبقًا']);
    } else {
        error_log("Subject create error: " . $e->getMessage());
        echo json_encode(['error' => 'فشل في الإنشاء']);
    }
}
?>