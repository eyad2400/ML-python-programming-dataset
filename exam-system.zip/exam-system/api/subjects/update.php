<?php
require '../db.php';
requireStaff();

$data = json_decode(file_get_contents('php://input'), true);

$subject_id = (int)($data['id'] ?? 0);
$name = trim($data['name'] ?? '');
$code = strtoupper(trim($data['code'] ?? ''));
$duration_minutes = (int)($data['duration_minutes'] ?? 60);
$description = trim($data['description'] ?? '');

if ($subject_id <= 0 || !$name || !$code || $duration_minutes < 15) {
    echo json_encode(['error' => 'بيانات غير صالحة']);
    exit;
}

$pdo = getDB();

// Check existence
$exists = $pdo->query("SELECT 1 FROM subjects WHERE id = $subject_id")->fetch();
if (!$exists) {
    echo json_encode(['error' => 'المادة غير موجودة']);
    exit;
}

try {
    $stmt = $pdo->prepare("
        UPDATE subjects 
        SET name = ?, code = ?, duration_minutes = ?, description = ?
        WHERE id = ?
    ");
    $stmt->execute([$name, $code, $duration_minutes, $description, $subject_id]);

    logActivity($_SESSION['user_id'], null, 'update_subject', "ID: $subject_id, Name: $name");

    echo json_encode(['success' => true, 'message' => 'تم التحديث']);
} catch (PDOException $e) {
    if ($e->getCode() == 23000) {
        echo json_encode(['error' => 'الكود موجود مسبقًا']);
    } else {
        echo json_encode(['error' => 'فشل في التحديث']);
    }
}
?>