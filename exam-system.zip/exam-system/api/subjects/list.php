<?php
require '../db.php';

// Optional: ?course_id=1 → only subjects in that course
$course_id = (int)($_GET['course_id'] ?? 0);

$pdo = getDB();

if ($course_id > 0) {
    // Subjects assigned to a specific course
    $subjects = $pdo->query("
        SELECT s.*, cs.course_id 
        FROM subjects s
        JOIN course_subjects cs ON s.id = cs.subject_id
        WHERE cs.course_id = $course_id
        ORDER BY s.name
    ")->fetchAll(PDO::FETCH_ASSOC);
} else {
    // All subjects
    $subjects = $pdo->query("
        SELECT s.*, 
               GROUP_CONCAT(cs.course_id) as course_ids
        FROM subjects s
        LEFT JOIN course_subjects cs ON s.id = cs.subject_id
        GROUP BY s.id
        ORDER BY s.name
    ")->fetchAll(PDO::FETCH_ASSOC);
}

echo json_encode($subjects, JSON_UNESCAPED_UNICODE);
?>