<?php
require '../db.php';
requireAdmin(); // Only Super Admin can delete

$subject_id = (int)($_POST['id'] ?? 0);
if ($subject_id <= 0) {
    echo json_encode(['error' => 'معرف المادة مطلوب']);
    exit;
}

$pdo = getDB();

// Check if used in any course
$used = $pdo->query("SELECT 1 FROM course_subjects WHERE subject_id = $subject_id")->fetch();
if ($used) {
    echo json_encode(['error' => 'لا يمكن حذف المادة: مستخدمة في دورة']);
    exit;
}

// Optional: Add `is_deleted` column for soft delete
// Here we use hard delete (safe because of check above)

$stmt = $pdo->prepare("DELETE FROM subjects WHERE id = ?");
$stmt->execute([$subject_id]);

logActivity($_SESSION['user_id'], null, 'delete_subject', "ID: $subject_id");

echo json_encode(['success' => true, 'message' => 'تم الحذف']);
?>