<?php
require '../db.php';
requireAdmin();

$course_id = json_decode(file_get_contents('php://input'), true)['course_id'];
$pdo = getDB();
$pdo->beginTransaction();

try {
  $course = $pdo->query("SELECT * FROM training_courses WHERE id = $course_id")->fetch();
  $pdo->prepare("INSERT INTO archived_courses (id, name, course_number, start_date, end_date, archived_by) VALUES (?, ?, ?, ?, ?, ?)")
    ->execute([$course['id'], $course['name'], $course['course_number'], $course['start_date'], $course['end_date'], $_SESSION['user_id']]);

  $trainees = $pdo->query("
    SELECT cta.national_id, COALESCE(AVG(ea.score), 0) as grade, COALESCE(AVG(ca.is_present)*100, 0) as attendance
    FROM course_trainee_assignments cta
    LEFT JOIN exam_attempts ea ON ea.national_id = cta.national_id AND ea.course_id = $course_id
    LEFT JOIN course_attendance ca ON ca.national_id = cta.national_id AND ca.course_id = $course_id
    WHERE cta.course_id = $course_id
    GROUP BY cta.national_id
  ")->fetchAll();

  foreach ($trainees as $t) {
    $pdo->prepare("INSERT INTO trainee_course_history (national_id, course_id, course_name, course_number, start_date, end_date, final_grade, attendance_percentage) VALUES (?, ?, ?, ?, ?, ?, ?, ?)")
      ->execute([$t['national_id'], $course_id, $course['name'], $course['course_number'], $course['start_date'], $course['end_date'], $t['grade'], $t['attendance']]);
  }

  $pdo->exec("DELETE FROM course_daily_schedule WHERE course_id = $course_id");
  $pdo->exec("DELETE FROM course_weekly_schedule WHERE course_id = $course_id");
  $pdo->exec("DELETE FROM course_subjects WHERE course_id = $course_id");
  $pdo->exec("DELETE FROM course_trainee_assignments WHERE course_id = $course_id");
  $pdo->exec("DELETE FROM training_courses WHERE id = $course_id");

  $pdo->commit();
  logActivity($_SESSION['user_id'], null, 'archive_course', "ID: $course_id");
  echo json_encode(['success' => true]);
} catch (Exception $e) {
  $pdo->rollBack();
  echo json_encode(['error' => 'فشل الأرشفة']);
}
?>