<?php
require '../db.php';
$name = $_GET['name'] ?? '';
if (!$name) exit(json_encode(['next_number' => 1]));

$pdo = getDB();
$max = $pdo->query("SELECT COALESCE(MAX(course_number), 0) FROM training_courses WHERE name = '$name'")->fetchColumn();
echo json_encode(['next_number' => $max + 1]);
?>