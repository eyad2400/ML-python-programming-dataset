<?php
require '../db.php';

// Optional filter: ?status=active|completed|all
$status = $_GET['status'] ?? 'all';
$pdo = getDB();

$sql = "
    SELECT 
        c.id, c.name, c.course_number, c.start_date, c.end_date,
        c.created_at, u.name_ar as creator_name,
        GROUP_CONCAT(s.name ORDER BY s.id SEPARATOR ', ') as subject_names
    FROM training_courses c
    LEFT JOIN users u ON c.created_by = u.id
    LEFT JOIN course_subjects cs ON c.id = cs.course_id
    LEFT JOIN subjects s ON cs.subject_id = s.id
";

$where = [];
$params = [];

if ($status === 'active') {
    $where[] = "c.end_date >= CURDATE()";
} elseif ($status === 'completed') {
    $where[] = "c.end_date < CURDATE()";
}

if (!empty($where)) {
    $sql .= " WHERE " . implode(' AND ', $where);
}

$sql .= " GROUP BY c.id ORDER BY c.start_date DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($courses, JSON_UNESCAPED_UNICODE);
?>