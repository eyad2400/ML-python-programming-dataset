<?php
require '../db.php';
$course_id = (int)($_GET['id'] ?? 0);

if ($course_id <= 0) {
    echo json_encode(['error' => 'معرف الدورة غير صالح']);
    exit;
}

$pdo = getDB();

// Course info
$course = $pdo->query("
    SELECT c.*, u.name_ar as creator_name 
    FROM training_courses c 
    LEFT JOIN users u ON c.created_by = u.id 
    WHERE c.id = $course_id
")->fetch(PDO::FETCH_ASSOC);

if (!$course) {
    echo json_encode(['error' => 'الدورة غير موجودة']);
    exit;
}

// Subjects
$subjects = $pdo->query("
    SELECT s.* 
    FROM subjects s 
    JOIN course_subjects cs ON s.id = cs.subject_id 
    WHERE cs.course_id = $course_id
")->fetchAll(PDO::FETCH_ASSOC);

// Trainees
$trainees = $pdo->query("
    SELECT et.national_id, et.name_ar,
           COALESCE(AVG(ea.score), 0) as avg_score,
           COALESCE(AVG(ca.is_present)*100, 0) as attendance_pct
    FROM exam_takers et
    JOIN course_trainee_assignments cta ON et.national_id = cta.national_id
    LEFT JOIN exam_attempts ea ON ea.national_id = et.national_id AND ea.course_id = $course_id
    LEFT JOIN course_attendance ca ON ca.national_id = et.national_id AND ca.course_id = $course_id
    WHERE cta.course_id = $course_id
    GROUP BY et.national_id
")->fetchAll(PDO::FETCH_ASSOC);

// Weekly Schedule
$weekly = $pdo->query("
    SELECT ws.*, s.name as subject_name, u.name_ar as trainer_name
    FROM course_weekly_schedule ws
    JOIN subjects s ON ws.subject_id = s.id
    JOIN users u ON ws.trainer_id = u.id
    WHERE ws.course_id = $course_id
    ORDER BY ws.day_of_week, ws.start_time
")->fetchAll(PDO::FETCH_ASSOC);

echo json_encode([
    'course' => $course,
    'subjects' => $subjects,
    'trainees' => $trainees,
    'weekly_schedule' => $weekly
], JSON_UNESCAPED_UNICODE);
?>