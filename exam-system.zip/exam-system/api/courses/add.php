<?php
// api/courses/add.php
require '../db.php';
requireStaff();

$data = json_decode(file_get_contents('php://input'), true);
$name = trim($data['name'] ?? '');
$start = $data['start_date'] ?? '';
$end = $data['end_date'] ?? '';

if (!$name || !$start || !$end || strtotime($end) <= strtotime($start)) {
    echo json_encode(['error' => 'بيانات غير صالحة']);
    exit;
}

$pdo = getDB();
$stmt = $pdo->prepare("SELECT MAX(course_number) FROM training_courses WHERE name = ?");
$stmt->execute([$name]);
$number = ($stmt->fetchColumn() ?: 0) + 1;

$stmt = $pdo->prepare("INSERT INTO training_courses (name, course_number, start_date, end_date, created_by) VALUES (?, ?, ?, ?, ?)");
$stmt->execute([$name, $number, $start, $end, $_SESSION['user_id']]);

$course_id = $pdo->lastInsertId();
logActivity($_SESSION['user_id'], null, 'course_added', "ID: $course_id");

echo json_encode(['success' => true, 'course_id' => $course_id, 'course_number' => $number]);
?>