<?php
require '../db.php';
requireStaff();

$data = json_decode(file_get_contents('php://input'), true);
$session_id = (int)($data['session_id'] ?? 0);
$start_time = $data['start_time'] ?? '';
$end_time = $data['end_time'] ?? '';
$trainer_id = (int)($data['trainer_id'] ?? 0);

if ($session_id <= 0 || !$start_time || !$end_time || $trainer_id <= 0) {
    echo json_encode(['error' => 'بيانات غير صالحة']);
    exit;
}

$pdo = getDB();
$session = $pdo->query("SELECT course_id, day_of_week FROM course_weekly_schedule WHERE id = $session_id")->fetch();
if (!$session) {
    echo json_encode(['error' => 'الجلسة غير موجودة']);
    exit;
}

// Check conflict
$conflict = $pdo->query("
    SELECT 1 FROM course_weekly_schedule 
    WHERE course_id = {$session['course_id']} 
      AND day_of_week = {$session['day_of_week']} 
      AND id != $session_id
      AND (start_time < '$end_time' AND end_time > '$start_time')
")->fetch();

if ($conflict) {
    echo json_encode(['error' => 'تضارب في الوقت']);
    exit;
}

$stmt = $pdo->prepare("UPDATE course_weekly_schedule SET start_time = ?, end_time = ?, trainer_id = ? WHERE id = ?");
$stmt->execute([$start_time, $end_time, $trainer_id, $session_id]);

logActivity($_SESSION['user_id'], null, 'update_weekly_session', "ID: $session_id");

echo json_encode(['success' => true]);
?>