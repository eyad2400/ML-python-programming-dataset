<?php
require '../db.php';
$course_id = (int)($_GET['course_id'] ?? 0);

$pdo = getDB();
$schedule = $pdo->query("
    SELECT 
        ws.*, s.name as subject_name, u.name_ar as trainer_name
    FROM course_weekly_schedule ws
    JOIN subjects s ON ws.subject_id = s.id
    JOIN users u ON ws.trainer_id = u.id
    WHERE ws.course_id = $course_id
    ORDER BY 
        FIELD(ws.day_of_week, 6,0,1,2,3,4),
        ws.start_time
")->fetchAll();

echo json_encode($schedule, JSON_UNESCAPED_UNICODE);
?>