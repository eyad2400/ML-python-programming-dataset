<?php
require '../db.php';
requireStaff();

$course_id = (int)($_GET['course_id'] ?? 0);
if ($course_id <= 0) {
    echo json_encode(['error' => 'معرف الدورة مطلوب']);
    exit;
}

$pdo = getDB();

// Get course dates
$course = $pdo->query("SELECT start_date, end_date FROM training_courses WHERE id = $course_id")->fetch();
if (!$course) {
    echo json_encode(['error' => 'الدورة غير موجودة']);
    exit;
}

// Get weekly template
$weekly = $pdo->query("SELECT * FROM course_weekly_schedule WHERE course_id = $course_id")->fetchAll();
if (empty($weekly)) {
    echo json_encode(['error' => 'لا يوجد جدول أسبوعي للدورة']);
    exit;
}

$current = new DateTime($course['start_date']);
$end = new DateTime($course['end_date']);
$end->modify('+1 day');
$generated = 0;

$pdo->beginTransaction();

while ($current < $end) {
    $day = (int)$current->format('w'); // 0=Sun, 6=Sat
    if (!in_array($day, [6,0,1,2,3,4])) { // Skip Friday
        $current->modify('+1 day');
        continue;
    }

    foreach ($weekly as $w) {
        if ($w['day_of_week'] == $day) {
            $date = $current->format('Y-m-d');
            $stmt = $pdo->prepare("
                INSERT IGNORE INTO course_daily_schedule 
                (course_id, schedule_date, subject_id, trainer_id, start_time, end_time, created_by)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $course_id, $date, $w['subject_id'], $w['trainer_id'],
                $w['start_time'], $w['end_time'], $_SESSION['user_id']
            ]);
            if ($stmt->rowCount() > 0) $generated++;
        }
    }
    $current->modify('+1 day');
}

$pdo->commit();

logActivity($_SESSION['user_id'], null, 'generate_daily_schedule', "Course: $course_id, Generated: $generated");

echo json_encode([
    'success' => true,
    'generated' => $generated,
    'message' => "تم إنشاء $generated جلسة يومية"
]);
?>