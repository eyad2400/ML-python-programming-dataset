<?php
require '../db.php';
requireStaff();

$session_id = (int)($_POST['session_id'] ?? 0);
if ($session_id <= 0) {
    echo json_encode(['error' => 'معرف الجلسة مطلوب']);
    exit;
}

$pdo = getDB();
$stmt = $pdo->prepare("DELETE FROM course_weekly_schedule WHERE id = ?");
$stmt->execute([$session_id]);

logActivity($_SESSION['user_id'], null, 'delete_weekly_session', "ID: $session_id");

echo json_encode(['success' => true]);
?>