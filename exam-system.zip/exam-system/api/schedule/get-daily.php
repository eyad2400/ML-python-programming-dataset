<?php
require '../db.php';
$course_id = (int)($_GET['course_id'] ?? 0);
$date = $_GET['date'] ?? '';

if ($course_id <= 0 || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
    echo json_encode(['error' => 'بيانات غير صالحة']);
    exit;
}

$pdo = getDB();
$schedule = $pdo->query("
    SELECT 
        ds.*, s.name as subject_name, u.name_ar as trainer_name
    FROM course_daily_schedule ds
    JOIN subjects s ON ds.subject_id = s.id
    JOIN users u ON ds.trainer_id = u.id
    WHERE ds.course_id = $course_id AND ds.schedule_date = '$date'
    ORDER BY ds.start_time
")->fetchAll();

echo json_encode($schedule, JSON_UNESCAPED_UNICODE);
?>