<?php
require '../db.php';
requireStaff(); // Only staff can create

$data = json_decode(file_get_contents('php://input'), true);

$course_id = (int)($data['course_id'] ?? 0);
$day_of_week = (int)($data['day_of_week'] ?? -1); // 6=Sat, 0=Sun, ..., 4=Thu
$subject_id = (int)($data['subject_id'] ?? 0);
$trainer_id = (int)($data['trainer_id'] ?? 0);
$start_time = $data['start_time'] ?? '';
$end_time = $data['end_time'] ?? '';

if ($course_id <= 0 || !in_array($day_of_week, [6,0,1,2,3,4]) || $subject_id <= 0 || $trainer_id <= 0 || !$start_time || !$end_time) {
    echo json_encode(['error' => 'بيانات غير صالحة']);
    exit;
}

if (!preg_match('/^\d{2}:\d{2}$/', $start_time) || !preg_match('/^\d{2}:\d{2}$/', $end_time)) {
    echo json_encode(['error' => 'صيغة الوقت غير صحيحة (HH:MM)']);
    exit;
}

if ($start_time >= $end_time) {
    echo json_encode(['error' => 'وقت البداية يجب أن يكون قبل النهاية']);
    exit;
}

$pdo = getDB();

// Validate course, subject, trainer
$course = $pdo->query("SELECT 1 FROM training_courses WHERE id = $course_id")->fetch();
$subject = $pdo->query("SELECT 1 FROM subjects WHERE id = $subject_id")->fetch();
$trainer = $pdo->query("SELECT 1 FROM users WHERE id = $trainer_id AND role = 'proctor'")->fetch();

if (!$course || !$subject || !$trainer) {
    echo json_encode(['error' => 'الدورة أو المادة أو المدرب غير موجود']);
    exit;
}

// Check subject is in course
$in_course = $pdo->query("SELECT 1 FROM course_subjects WHERE course_id = $course_id AND subject_id = $subject_id")->fetch();
if (!$in_course) {
    echo json_encode(['error' => 'المادة غير مضافة للدورة']);
    exit;
}

// Check for time conflict on same day
$conflict = $pdo->query("
    SELECT 1 FROM course_weekly_schedule 
    WHERE course_id = $course_id 
      AND day_of_week = $day_of_week 
      AND (
        (start_time < '$end_time' AND end_time > '$start_time')
      )
")->fetch();

if ($conflict) {
    echo json_encode(['error' => 'تضارب في الوقت مع جلسة أخرى في نفس اليوم']);
    exit;
}

$stmt = $pdo->prepare("
    INSERT INTO course_weekly_schedule 
    (course_id, day_of_week, subject_id, trainer_id, start_time, end_time, created_by)
    VALUES (?, ?, ?, ?, ?, ?, ?)
");
$stmt->execute([$course_id, $day_of_week, $subject_id, $trainer_id, $start_time, $end_time, $_SESSION['user_id']]);

$session_id = $pdo->lastInsertId();

logActivity($_SESSION['user_id'], null, 'create_weekly_session', 
    "Course: $course_id, Day: $day_of_week, Time: $start_time–$end_time");

echo json_encode([
    'success' => true,
    'session_id' => $session_id,
    'message' => 'تم إنشاء الجلسة الأسبوعية'
]);
?>