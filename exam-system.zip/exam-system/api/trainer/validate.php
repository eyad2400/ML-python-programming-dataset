<?php
require '../db.php';
$token = $_GET['token'] ?? '';

if (!$token) {
    echo json_encode(['valid' => false]);
    exit;
}

$pdo = getDB();

$session = $pdo->query("
    SELECT ts.*, t.name_ar, t.national_id 
    FROM trainer_sessions ts
    JOIN trainers t ON ts.trainer_id = t.id
    WHERE ts.token = '$token' AND ts.expires_at > NOW()
")->fetch();

if (!$session) {
    echo json_encode(['valid' => false]);
    exit;
}

echo json_encode([
    'valid' => true,
    'trainer' => [
        'id' => $session['trainer_id'],
        'name_ar' => $session['name_ar'],
        'national_id' => $session['national_id']
    ]
], JSON_UNESCAPED_UNICODE);
?>