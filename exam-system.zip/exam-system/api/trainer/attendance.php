<?php
require '../db.php';
$session_id = (int)($_GET['session_id'] ?? 0);
$date = $_GET['date'] ?? '';
$token = $_GET['token'] ?? '';

if ($session_id <= 0 || !$date || !$token) {
    echo json_encode(['error' => 'Invalid']);
    exit;
}

$pdo = getDB();
$session = validateTrainerToken($token);
if (!$session) exit(json_encode(['valid' => false]));

$daily = $pdo->query("
    SELECT course_id, subject_id, start_time 
    FROM course_daily_schedule 
    WHERE id = $session_id AND trainer_id = {$session['trainer_id']}
")->fetch();

if (!$daily) exit(json_encode(['error' => 'Session not found']));

$trainees = $pdo->query("
    SELECT 
        et.national_id, et.name_ar,
        COALESCE(ca.is_present, 0) as is_present
    FROM course_trainee_assignments cta
    JOIN exam_takers et ON cta.national_id = et.national_id
    LEFT JOIN course_attendance ca 
      ON ca.course_id = cta.course_id 
      AND ca.national_id = et.national_id 
      AND ca.attendance_date = '$date'
    WHERE cta.course_id = {$daily['course_id']}
    ORDER BY et.name_ar
")->fetchAll();

echo json_encode([
    'session' => $daily,
    'trainees' => $trainees
], JSON_UNESCAPED_UNICODE);
?>