<?php
require '../db.php';
$exam_id = (int)($_GET['exam_id'] ?? 0);
$token = $_GET['token'] ?? '';

if ($exam_id <= 0 || !$token) exit(json_encode(['error' => 'Invalid']));

$pdo = getDB();
$session = validateTrainerToken($token);
if (!$session) exit(json_encode(['valid' => false]));

$results = $pdo->query("
    SELECT 
        et.name_ar,
        ea.score,
        TIMESTAMPDIFF(MINUTE, ea.start_time, ea.end_time) as duration
    FROM exam_attempts ea
    JOIN exam_takers et ON ea.national_id = et.national_id
    JOIN exams e ON ea.exam_id = e.id
    JOIN subjects s ON e.subject_id = s.id
    JOIN trainer_subjects ts ON s.id = ts.subject_id
    WHERE ea.exam_id = $exam_id AND ts.trainer_id = {$session['trainer_id']}
    ORDER BY ea.score DESC
")->fetchAll();

echo json_encode([
    'results' => $results
], JSON_UNESCAPED_UNICODE);
?>