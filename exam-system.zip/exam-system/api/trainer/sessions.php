<?php
require '../db.php';
$token = $_GET['token'] ?? '';
if (!$token) exit(json_encode(['valid' => false]));

$pdo = getDB();
$session = validateTrainerToken($token);
if (!$session) exit(json_encode(['valid' => false]));

$sessions = $pdo->query("
    SELECT 
        ds.id, ds.schedule_date,
        c.name as course_name, c.course_number,
        s.name as subject_name,
        ds.start_time, ds.end_time
    FROM course_daily_schedule ds
    JOIN training_courses c ON ds.course_id = c.id
    JOIN subjects s ON ds.subject_id = s.id
    WHERE ds.trainer_id = {$session['trainer_id']}
      AND ds.schedule_date >= CURDATE()
    ORDER BY ds.schedule_date, ds.start_time
")->fetchAll();

echo json_encode([
    'valid' => true,
    'sessions' => $sessions
], JSON_UNESCAPED_UNICODE);
?>