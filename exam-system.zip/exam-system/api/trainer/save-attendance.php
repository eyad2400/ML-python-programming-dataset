<?php
require '../db.php';
$data = json_decode(file_get_contents('php://input'), true);

$session_id = (int)($data['session_id'] ?? 0);
$date = $data['date'] ?? '';
$attendance = $data['attendance'] ?? [];

if ($session_id <= 0 || !$date || !is_array($attendance)) {
    echo json_encode(['error' => 'Invalid data']);
    exit;
}

$pdo = getDB();
$trainer = validateTrainerToken($data['token'] ?? '');
if (!$trainer) exit(json_encode(['error' => 'Invalid token']));

$daily = $pdo->query("SELECT course_id FROM course_daily_schedule WHERE id = $session_id")->fetchColumn();
if (!$daily) exit(json_encode(['error' => 'Session not found']));

$pdo->beginTransaction();
foreach ($attendance as $item) {
    $national_id = $item['national_id'];
    $present = (int)$item['is_present'];

    $stmt = $pdo->prepare("
        INSERT INTO course_attendance 
        (course_id, national_id, attendance_date, is_present, marked_by, marked_at)
        VALUES (?, ?, ?, ?, ?, NOW())
        ON DUPLICATE KEY UPDATE is_present = ?, marked_by = ?, marked_at = NOW()
    ");
    $stmt->execute([$daily, $national_id, $date, $present, $trainer['trainer_id'], $present, $trainer['trainer_id']]);
}
$pdo->commit();

logActivity(null, null, 'trainer_marked_attendance', "Session: $session_id, Date: $date");

echo json_encode(['success' => true]);
?>