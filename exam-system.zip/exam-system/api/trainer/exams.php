<?php
require '../db.php';
$token = $_GET['token'] ?? '';
if (!$token) exit(json_encode(['valid' => false]));

$pdo = getDB();
$session = validateTrainerToken($token);
if (!$session) exit(json_encode(['valid' => false]));

$exams = $pdo->query("
    SELECT DISTINCT
        e.id as exam_id,
        c.name as course_name, c.course_number,
        s.name as subject_name
    FROM exams e
    JOIN subjects s ON e.subject_id = s.id
    JOIN trainer_subjects ts ON s.id = ts.subject_id
    JOIN course_subjects cs ON s.id = cs.subject_id
    JOIN training_courses c ON cs.course_id = c.id
    WHERE ts.trainer_id = {$session['trainer_id']}
")->fetchAll();

echo json_encode([
    'valid' => true,
    'exams' => $exams
], JSON_UNESCAPED_UNICODE);
?>