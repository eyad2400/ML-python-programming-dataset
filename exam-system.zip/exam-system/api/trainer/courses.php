<?php
require '../db.php';
$token = $_GET['token'] ?? '';
if (!$token) exit(json_encode(['valid' => false]));

$pdo = getDB();
$session = validateTrainerToken($token);
if (!$session) exit(json_encode(['valid' => false]));

$courses = $pdo->query("
    SELECT DISTINCT
        c.id, c.name as course_name, c.course_number,
        c.start_date, c.end_date,
        s.name as subject_name,
        COUNT(w.id) as session_count
    FROM training_courses c
    JOIN course_subjects cs ON c.id = cs.course_id
    JOIN subjects s ON cs.subject_id = s.id
    JOIN trainer_subjects ts ON s.id = ts.subject_id
    LEFT JOIN course_weekly_schedule w ON c.id = w.course_id AND w.trainer_id = {$session['trainer_id']}
    WHERE ts.trainer_id = {$session['trainer_id']}
    GROUP BY c.id, s.id
    ORDER BY c.start_date DESC
")->fetchAll();

echo json_encode([
    'valid' => true,
    'courses' => $courses
], JSON_UNESCAPED_UNICODE);
?>