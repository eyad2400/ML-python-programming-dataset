<?php
require '../db.php';
$data = json_decode(file_get_contents('php://input'), true);

$national_id = preg_replace('/\D/', '', $data['national_id'] ?? '');
$pin = $data['pin'] ?? '';

if (!preg_match('/^\d{14}$/', $national_id) || !preg_match('/^\d{4}$/', $pin)) {
    echo json_encode(['error' => 'بيانات غير صالحة']);
    exit;
}

$pdo = getDB();

$trainer = $pdo->query("
    SELECT id, name_ar, national_id 
    FROM trainers 
    WHERE national_id = '$national_id' AND pin = '$pin'
")->fetch();

if (!$trainer) {
    logActivity(null, $national_id, 'trainer_login_failed', 'Wrong PIN');
    echo json_encode(['error' => 'رقم قومي أو رمز غير صحيح']);
    exit;
}

// Generate 2-hour token
$token = bin2hex(random_bytes(32));
$expires = date('Y-m-d H:i:s', time() + 7200); // 2 hours

$stmt = $pdo->prepare("
    INSERT INTO trainer_sessions (trainer_id, token, expires_at, ip_address)
    VALUES (?, ?, ?, ?)
    ON DUPLICATE KEY UPDATE token = ?, expires_at = ?, ip_address = ?
");
$stmt->execute([
    $trainer['id'], $token, $expires, $_SERVER['REMOTE_ADDR'],
    $token, $expires, $_SERVER['REMOTE_ADDR']
]);

logActivity(null, $national_id, 'trainer_login_success', "Trainer ID: {$trainer['id']}");

echo json_encode([
    'success' => true,
    'token' => $token,
    'trainer_id' => $trainer['id'],
    'name' => $trainer['name_ar']
], JSON_UNESCAPED_UNICODE);
?>