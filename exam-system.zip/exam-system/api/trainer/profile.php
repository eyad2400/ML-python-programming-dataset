<?php
require '../db.php';
$token = $_GET['token'] ?? '';
if (!$token) exit(json_encode(['valid' => false]));

$pdo = getDB();
$session = validateTrainerToken($token);
if (!$session) exit(json_encode(['valid' => false]));

$subjects = $pdo->query("
    SELECT s.name 
    FROM subjects s 
    JOIN trainer_subjects ts ON s.id = ts.subject_id 
    WHERE ts.trainer_id = {$session['trainer_id']}
")->fetchAll(PDO::FETCH_COLUMN);

$session_count = $pdo->query("
    SELECT COUNT(*) 
    FROM course_daily_schedule 
    WHERE trainer_id = {$session['trainer_id']}
")->fetchColumn();

echo json_encode([
    'trainer' => [
        'name_ar' => $session['name_ar'],
        'national_id' => $session['national_id']
    ],
    'subjects' => $subjects,
    'session_count' => (int)$session_count
], JSON_UNESCAPED_UNICODE);
?>