<?php
require '../api/db.php';
requireStaff();
if (!$_SESSION['is_super_admin']) {
    die('غير مصرح');
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <title>إدارة الملفات</title>
  <link rel="stylesheet" href="../assets/css/style.css" />
  <link rel="stylesheet" href="assets/uploads.css" />
</head>
<body>
<div class="container">
  <div class="card">
    <div class="card-header">إدارة الملفات</div>
    <form id="upload-form" enctype="multipart/form-data">
      <input type="file" name="file" required class="mt-2" />
      <button type="submit" class="btn btn-success btn-sm mt-2">رفع</button>
    </form>
    <div id="upload-status"></div>
    <table class="table mt-3">
      <thead>
        <tr><th>الاسم</th><th>الحجم</th><th>التاريخ</th><th>الإجراء</th></tr>
      </thead>
      <tbody id="files-list"></tbody>
    </table>
  </div>
</div>

<script src="../assets/js/main.js"></script>
<script>
async function loadFiles() {
  const res = await get('/uploads/api/list.php');
  const tbody = document.getElementById('files-list');
  tbody.innerHTML = res.files.map(f => `
    <tr>
      <td><a href="/uploads/api/download.php?id=${f.id}" target="_blank">${f.filename}</a></td>
      <td>${formatBytes(f.size)}</td>
      <td>${formatDate(f.uploaded_at)}</td>
      <td><button class="btn btn-danger btn-sm" onclick="deleteFile(${f.id})">حذف</button></td>
    </tr>
  `).join('');
}

async function deleteFile(id) {
  if (confirm('حذف الملف؟')) {
    const res = await post('/uploads/api/delete.php', { id });
    toast(res.success ? 'تم الحذف' : res.error);
    loadFiles();
  }
}

document.getElementById('upload-form').onsubmit = async function(e) {
  e.preventDefault();
  const form = e.target;
  const file = form.file.files[0];
  if (!file) return;

  const formData = new FormData();
  formData.append('file', file);

  const btn = form.querySelector('button');
  showLoading(btn);
  const res = await fetch('/uploads/api/upload.php', {
    method: 'POST',
    body: formData
  }).then(r => r.json());
  hideLoading(btn, 'رفع');

  document.getElementById('upload-status').innerHTML = 
    res.success ? '<p class="text-success">تم الرفع</p>' : `<p class="text-danger">${res.error}</p>`;
  form.reset();
  loadFiles();
};

loadFiles();
</script>
</body>
</html>