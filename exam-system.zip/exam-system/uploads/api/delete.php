<?php
require '../../api/db.php';
requireStaff();
$data = json_decode(file_get_contents('php://input'), true);

$id = (int)($data['id'] ?? 0);
if ($id <= 0) {
    echo json_encode(['error' => 'Invalid ID']);
    exit;
}

$pdo = getDB();
$file = $pdo->query("SELECT filename FROM uploaded_files WHERE id = $id")->fetchColumn();
if (!$file) {
    echo json_encode(['error' => 'File not found']);
    exit;
}

$path = __DIR__ . '/../storage/' . $file;
if (file_exists($path)) unlink($path);

$pdo->prepare("DELETE FROM uploaded_files WHERE id = ?")->execute([$id]);

logActivity($_SESSION['user_id'], null, 'file_delete', "ID: $id");

echo json_encode(['success' => true]);
?>