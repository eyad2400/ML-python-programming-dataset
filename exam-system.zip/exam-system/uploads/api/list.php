<?php
require '../../api/db.php';
requireStaff();

$pdo = getDB();
$files = $pdo->query("
    SELECT id, original_name as filename, size, uploaded_at
    FROM uploaded_files
    ORDER BY uploaded_at DESC
")->fetchAll();

echo json_encode(['files' => $files], JSON_UNESCAPED_UNICODE);
?>