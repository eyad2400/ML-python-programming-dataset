<?php
require '../../api/db.php';
requireStaff();

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    die('Invalid');
}

$pdo = getDB();
$file = $pdo->query("
    SELECT filename, original_name, mime_type 
    FROM uploaded_files 
    WHERE id = $id
")->fetch();

if (!$file) {
    die('File not found');
}

$path = __DIR__ . '/../storage/' . $file['filename'];
if (!file_exists($path)) {
    die('File missing');
}

logActivity($_SESSION['user_id'], null, 'file_download', "File: {$file['original_name']}");

header('Content-Type: ' . $file['mime_type']);
header('Content-Disposition: attachment; filename="' . $file['original_name'] . '"');
header('Content-Length: ' . filesize($path));
readfile($path);
exit;
?>