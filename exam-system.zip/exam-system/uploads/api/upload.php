<?php
require '../../api/db.php';
requireStaff();

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_FILES['file'])) {
    echo json_encode(['error' => 'No file']);
    exit;
}

$file = $_FILES['file'];
$uploadDir = __DIR__ . '/../storage/';
$allowed = [
    'csv' => 'text/csv',
    'pdf' => 'application/pdf',
    'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'jpg' => 'image/jpeg',
    'png' => 'image/png'
];

$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
if (!isset($allowed[$ext])) {
    echo json_encode(['error' => 'نوع الملف غير مدعوم']);
    exit;
}

if ($file['size'] > 10 * 1024 * 1024) { // 10MB
    echo json_encode(['error' => 'الملف كبير جداً']);
    exit;
}

// Virus scan (ClamAV)
if (function_exists('clamav_scan')) {
    $scan = clamav_scan($file['tmp_name']);
    if (!$scan['ok']) {
        echo json_encode(['error' => 'فيروس محتمل']);
        exit;
    }
}

// Generate safe filename
$filename = bin2hex(random_bytes(16)) . '.' . $ext;
$path = $uploadDir . $filename;

if (!move_uploaded_file($file['tmp_name'], $path)) {
    echo json_encode(['error' => 'فشل الرفع']);
    exit;
}

$pdo = getDB();
$stmt = $pdo->prepare("
    INSERT INTO uploaded_files (filename, original_name, mime_type, size, uploaded_by)
    VALUES (?, ?, ?, ?, ?)
");
$stmt->execute([
    $filename,
    $file['name'],
    $allowed[$ext],
    $file['size'],
    $_SESSION['user_id']
]);

logActivity($_SESSION['user_id'], null, 'file_upload', "File: {$file['name']}");

echo json_encode(['success' => true]);
?>